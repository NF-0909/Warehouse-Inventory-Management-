<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="bean.Customer"%>
<%@page import="bean.Payment"%>
<%@page import="dao.PaymentDAO"%>
<%@page import="java.util.ArrayList"%>

<%
Customer customer = (Customer)session.getAttribute("customer");

if(customer == null){
    response.sendRedirect("login.jsp");
    return;
}

PaymentDAO paymentDAO = new PaymentDAO();
ArrayList<Payment> payments = paymentDAO.getPaymentsByCustomer(customer.getCustomerID());
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Transaction History</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .status-paid { color: #2ecc71; font-weight: bold; }
    </style>
</head>
<body>

<div class="sidebar">

    <div class="sidebar-items">
        <div>
            <div class="logo">
                <a href="dashboard.jsp">Equipment Rental System</a>
            </div>

            <div class="menu">
                <a href="dashboard.jsp">Dashboard</a>
                <a href="EquipmentCatalog.jsp">Equipment Catalog</a>
                <a href="RentingStatus.jsp">Renting Status</a>
                <a href="Transaction.jsp">Transaction</a>
                <a href="CustomerProfile.jsp">Profile</a>
                <br><br><br><br>
                <a href="LogoutServlet">Logout</a>
            </div>
        </div>

        <div class="profile">
            <div class="avatar"></div>
            <div>
                <h3><%=customer.getUserName()%></h3>
                <p style="color:#999;">Customer</p>
            </div>
        </div>
    </div>

    <div class="main">

        <div class="welcome">
            <h1>Transaction History</h1>
            <p>Track all payments and rental fees for your account</p>
        </div>

        <div class="dashboard-card">
            <div class="past-rental" style="width:100%;">
                <h3>Payment History</h3>

                <table>
                    <tr>
                        <th>Payment ID</th>
                        <th>Rental ID</th>
                        <th>Equipment</th>
                        <th>Amount (RM)</th>
                        <th>Payment Date</th>
                        <th>Method</th>
                        <th>Status</th>
                    </tr>
                    <%
                    if(payments.isEmpty()){
                    %>
                    <tr>
                        <td colspan="7" align="center">No payments found.</td>
                    </tr>
                    <%
                    }else{
                        for(Payment p : payments){
                    %>
                    <tr>
                        <td><%=p.getPaymentID()%></td>
                        <td><%=p.getRentalID()%></td>
                        <td><%=p.getEquipmentName()%></td>
                        <td><%=String.format("%.2f", p.getAmount())%></td>
                        <td><%=p.getPaymentDate()%></td>
                        <td><%=p.getPaymentMethod()%></td>
                        <td><span class="status-paid">Paid</span></td>
                    </tr>
                    <%
                        }
                    }
                    %>
                </table>

            </div>
        </div>

    </div>

</div>

</body>
</html>
