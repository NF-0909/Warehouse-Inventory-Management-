<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%@page import="bean.Employee"%>
<%@page import="bean.Rental"%>
<%@page import="dao.RentalsDAO"%>
<%@page import="java.util.ArrayList"%>


<%

    Employee employee =
            (Employee) session.getAttribute("employee");


    if(employee == null){

        response.sendRedirect("login.jsp");
        return;

    }


    RentalsDAO dao =
            new RentalsDAO();


    ArrayList<Rental> rentals =
            dao.getPendingRentals();


%>



<!DOCTYPE html>

<html>

<head>

    <meta charset="UTF-8">

    <title>
        Pending Rentals
    </title>


    <link rel="stylesheet" href="css/style.css">


    <style>


        body {

            background-color:#0f172a;

            color:white;

        }



        .main {

            padding:40px;

        }




        .welcome h1 {


            font-size:2.5rem;

            margin-bottom:5px;

            color:white;


        }




        .welcome p {


            color:#94a3b8;

            margin-bottom:30px;


        }





        .content-container {


            background-color:#1e293b;


            border-radius:15px;


            padding:30px;


            max-width:1100px;


            box-shadow:
            0 10px 25px rgba(0,0,0,0.3);


        }






        .section-title {


            color:white;


            font-size:1.3rem;


            font-weight:600;


            margin-bottom:20px;


        }






        .data-table {


            width:100%;


            border-collapse:collapse;


        }





        .data-table th {


            background-color:#0f172a;


            color:#94a3b8;


            padding:14px;


            text-align:left;


            font-size:0.9rem;


        }







        .data-table td {


            padding:16px;


            border-bottom:
            1px solid #334155;


            color:#f8fafc;


        }







        .badge {


            padding:5px 12px;


            border-radius:20px;


            font-size:0.8rem;


            font-weight:600;


        }







        .pending {


            background-color:
            rgba(245,158,11,0.15);


            color:#f59e0b;


        }







        .btn-action {


            background-color:#10b981;


            color:white;


            border:none;


            padding:8px 16px;


            border-radius:6px;


            cursor:pointer;


            font-weight:600;


        }







        .btn-action:hover {


            background-color:#047857;


        }






        .empty {


            text-align:center;


            color:#94a3b8;


        }



    </style>



</head>



<body>



<div class="sidebar">



    <div class="sidebar-items">



        <div>



            <div class="logo">


                <a href="employeeDashboard.jsp">


                    Equipment Rental System


                </a>


            </div>





                        <div class="menu">
                <a href="employeeDashboard.jsp">Dashboard</a>
                <a href="EquipmentList.jsp">Equipment List</a>
                <a href="pendingRentals.jsp">Pending Rentals</a>
                <a href="maintenanceList.jsp">Maintenance List</a>
                <a href="maintenanceHistory.jsp">Maintenance History</a>
                <a href="EmployeeProfile.jsp">Profile</a>
                <br><br><br><br>
                <a href="LogoutServlet">Logout</a>
            </div>



        </div>






                <div class="profile">
            <div class="avatar" style="background: linear-gradient(135deg, #10b981, #047857);">E</div>
            <div>
                <h3><%= employee.getEmployeeName() %></h3>
                <p style="color:#999;"><%= employee.getPosition() %></p>
            </div>
        </div>



    </div>








    <div class="main">



        <div class="welcome">


            <h1>

                Pending Rentals

            </h1>



            <p>

                Review and approve customer rental requests.

            </p>


        </div>






        <div class="content-container">



            <h3 class="section-title">

                Rental Approval Queue

            </h3>







            <table class="data-table">



                <thead>


                    <tr>


                        <th>

                            Rental ID

                        </th>


                        <th>

                            Customer

                        </th>


                        <th>

                            Equipment

                        </th>


                        <th>

                            Start Date

                        </th>


                        <th>

                            Status

                        </th>


                        <th>

                            Action

                        </th>


                    </tr>


                </thead>





                <tbody>



                <%

                    if(rentals.isEmpty()){


                %>



                    <tr>


                        <td colspan="6"
                            class="empty">


                            No pending rental requests.


                        </td>


                    </tr>




                <%

                    }

                    else{


                        for(Rental rental : rentals){


                %>




                    <tr>



                        <td>

                            <%=rental.getRentalID()%>

                        </td>




                        <td>

                            <%=rental.getCustomerName()%>

                        </td>




                        <td>

                            <%=rental.getEquipmentName()%>

                        </td>




                        <td>

                            <%=rental.getStartDate()%>

                        </td>




                        <td>


                            <span class="badge pending">


                                <%=rental.getStatus()%>


                            </span>


                        </td>




                        <td>



                            <form action="ApproveRentalServlet"
                                  method="post">



                                <input type="hidden"
                                       name="rentalID"
                                       value="<%=rental.getRentalID()%>">





                                <button type="submit"
                                        class="btn-action">


                                    Approve


                                </button>




                            </form>



                        </td>




                    </tr>




                <%

                        }

                    }


                %>




                </tbody>



            </table>




        </div>




    </div>



</div>



</body>



</html>