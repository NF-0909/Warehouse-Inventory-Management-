<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%@page import="bean.Maintenance"%>
<%@page import="dao.MaintenanceDAO"%>
<%@page import="bean.Employee"%>


<%

Employee employee =
(Employee) session.getAttribute("employee");


if (employee == null) {

    response.sendRedirect("login.jsp");
    return;

}


String idParameter = request.getParameter("id");


if (idParameter == null) {

    response.sendRedirect("maintenanceList.jsp");
    return;

}


int id = Integer.parseInt(idParameter);


MaintenanceDAO dao =
new MaintenanceDAO();


Maintenance m =
dao.getMaintenanceByID(id);


if (m == null) {

    response.sendRedirect("maintenanceList.jsp");
    return;

}

%>


<!DOCTYPE html>

<html>

<head>

    <meta charset="UTF-8">

    <title>
        Update Maintenance
    </title>


    <link rel="stylesheet" href="css/style.css">


    <style>

        body {

            background-color: #0f172a;
            color: white;

        }


        .main {

            padding: 40px;

        }


        .welcome h1 {

            font-size: 2.5rem;
            margin-bottom: 5px;

        }


        .welcome p {

            color: #94a3b8;
            margin-bottom: 30px;

        }


        .form-container {

            background-color: #1e293b;

            border-radius: 15px;

            padding: 40px;

            max-width: 700px;

            box-shadow:
            0 10px 25px rgba(0,0,0,0.3);

        }


        .form-group {

            margin-bottom: 20px;

        }


        .form-group label {

            display: block;

            margin-bottom: 8px;

            color: #94a3b8;

        }


        .form-group input,
        .form-group select,
        .form-group textarea {

            width: 100%;

            padding: 12px;

            border-radius: 8px;

            border: 1px solid #334155;

            box-sizing: border-box;

            font-size: 1rem;

        }


        .form-group input[readonly] {

            background-color: #334155;

            color: white;

        }


        textarea {

            height: 120px;

            resize: none;

        }


        .button-container {

            display: flex;

            gap: 15px;

            margin-top: 25px;

        }


        .btn-save {

            background-color: #3b82f6;

            color: white;

            padding: 12px 30px;

            border: none;

            border-radius: 8px;

            cursor: pointer;

            font-size: 1rem;

        }


        .btn-save:hover {

            background-color: #2563eb;

        }


        .btn-cancel {

            background-color: #475569;

            color: white;

            padding: 12px 30px;

            border-radius: 8px;

            text-decoration: none;

        }


        .btn-cancel:hover {

            background-color: #334155;

        }


    </style>


</head>


<body>


<div class="sidebar">


    <div class="sidebar-items">


        <div>


            <div class="logo">

                <a href="employeeDashboard.jsp">

                    Equipment Rental System

                </a>

            </div>


                        <div class="menu">
                <a href="employeeDashboard.jsp">Dashboard</a>
                <a href="EquipmentList.jsp">Equipment List</a>
                <a href="pendingRentals.jsp">Pending Rentals</a>
                <a href="maintenanceList.jsp">Maintenance List</a>
                <a href="maintenanceHistory.jsp">Maintenance History</a>
                <a href="EmployeeProfile.jsp">Profile</a>
                <br><br><br><br>
                <a href="LogoutServlet">Logout</a>
            </div>


        </div>



                <div class="profile">
            <div class="avatar" style="background: linear-gradient(135deg, #10b981, #047857);">E</div>
            <div>
                <h3><%= employee.getEmployeeName() %></h3>
                <p style="color:#999;"><%= employee.getPosition() %></p>
            </div>
        </div>


    </div>



    <div class="main">


        <div class="welcome">


            <h1>

                Update Service Progress

            </h1>


            <p>

                Modify maintenance status and repair information.

            </p>


        </div>



        <div class="form-container">



            <form action="UpdateMaintenanceServlet"
                  method="post">

                <div class="form-group">


                    <label>

                        Maintenance ID

                    </label>


                    <input type="text"
                           name="maintenanceID"
                           value="<%=m.getMaintenanceID()%>"
                           readonly>


                </div>




                <div class="form-group">


                    <label>

                        Equipment ID

                    </label>


                    <input type="text"
                           value="<%=m.getEquipmentID()%>"
                           readonly>


                </div>




                <div class="form-group">


                    <label>

                        Status Update

                    </label>


                    <select name="status">


                        <option value="Pending"
                            <%="Pending".equals(m.getStatus()) ? "selected" : ""%>>

                            Pending

                        </option>


                        <option value="In Progress"
                            <%="In Progress".equals(m.getStatus()) ? "selected" : ""%>>

                            In Progress

                        </option>


                        <option value="Awaiting Parts"
                            <%="Awaiting Parts".equals(m.getStatus()) ? "selected" : ""%>>

                            Awaiting Parts

                        </option>


                        <option value="Completed"
                            <%="Completed".equals(m.getStatus()) ? "selected" : ""%>>

                            Completed

                        </option>


                    </select>


                </div>




                <div class="form-group">


                    <label>

                        Maintenance Diagnostic Logs & Remarks

                    </label>


                    <textarea name="remarks"><%=m.getIssue()%></textarea>


                </div>




                <div class="button-container">


                    <button type="submit"
                            class="btn-save">

                        Save Changes

                    </button>


                    <a href="maintenanceList.jsp"
                       class="btn-cancel">

                        Cancel

                    </a>


                </div>


            </form>


        </div>


    </div>


</div>


</body>


</html>