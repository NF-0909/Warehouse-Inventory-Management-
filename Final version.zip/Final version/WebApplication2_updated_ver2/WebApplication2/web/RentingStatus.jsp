<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="bean.Customer"%>
<%@page import="bean.Rental"%>
<%@page import="dao.RentalsDAO"%>
<%@page import="java.util.ArrayList"%>

<%
Customer customer = (Customer)session.getAttribute("customer");
if(customer == null){

    response.sendRedirect("login.jsp");
    return;

}

RentalsDAO dao = new RentalsDAO();

ArrayList<Rental> rentals =
dao.getRentalsByCustomer(customer.getCustomerID());
%>

<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <title>Renting Status</title>

    <link rel="stylesheet" href="css/style.css">

</head>

<body>

<div class="sidebar">

    <!-- SIDEBAR -->

    <div class="sidebar-items">

        <div>

            <div class="logo">
                <a href="dashboard.jsp">
                    Equipment Rental System
                </a>
            </div>

            <div class="menu">

                <a href="dashboard.jsp">Dashboard</a>

                <a href="EquipmentCatalog.jsp">Equipment Catalog</a>

                <a href="RentingStatus.jsp">Renting Status</a>

                <a href="Transaction.jsp">Transaction</a>

                <a href="CustomerProfile.jsp">Profile</a>

                <br><br><br><br>

                <a href="LogoutServlet">Logout</a>

            </div>

        </div>

        <div class="profile">

            <div class="avatar"></div>

            <div>
                <h3><%=customer.getUserName()%></h3>
                <p style="color:#999;">Equipment Manager</p>
            </div>

        </div>

    </div>

    <!-- MAIN CONTENT -->

    <div class="main">

        <div class="welcome">
            <h1>Renting Status</h1>
            <p>Current rental records and status</p>
        </div>

        <div class="dashboard-card">

            <div class="past-rental" style="width:100%;">

                <h3>Rental Records</h3>

                <table>

                        <tr>
                            <th>Rental ID</th>
                            <th>Equipment</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Status</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                        <%
                            if(rentals.isEmpty()){
                        %>

                        <tr>
                            <td colspan="6" align="center">
                                No rentals found.
                            </td>
                        </tr>

                    <%}else{
                        for(Rental r : rentals){
                    %>

                        <tr>
                            <td><%=r.getRentalID()%></td>
                            <td><%=r.getEquipmentName()%></td>
                            <td><%=r.getStartDate()%></td>
                            <td><%=r.getEndDate()%></td>
                            <td><%=r.getStatus()%></td>
                            <td>RM <%=String.format("%.2f", r.getTotalAmount())%></td>
                            <td>
                                <%
                                if(!r.getStatus().equalsIgnoreCase("Completed")){
                                %>

                                <a href="ReturnRentalServlet?rentalID=<%=r.getRentalID()%>">
                                    Return
                                </a>
                                <%
                                }else{
                                %>
                                Returned
                                <%
                                }
                                %>

                                </td>
                        </tr>

                        <%
                        }
                        }
                        %>

                </table>

            </div>

        </div>

    </div>

</div>

</body>
</html>