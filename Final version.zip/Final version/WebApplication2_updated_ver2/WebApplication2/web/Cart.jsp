<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.ArrayList"%>
<%@page import="dao.CartDAO"%>
<%@page import="bean.Cart"%>
<%@page import="bean.Customer"%>

<%
Customer customer = (Customer)session.getAttribute("customer");

if(customer == null){
    response.sendRedirect("login.jsp");
    return;
}

CartDAO cartDAO = new CartDAO();
ArrayList<Cart> cartItems = cartDAO.getCartByCustomer(customer.getCustomerID());

String cartError = (String) session.getAttribute("cartError");
session.removeAttribute("cartError");
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Your Cart</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="sidebar">
    <div class="sidebar-items">
        <div>
            <div class="logo">
                <a href="dashboard.jsp">Equipment Rental System</a>
            </div>
            <div class="menu">
                <a href="dashboard.jsp">Dashboard</a>
                <a href="EquipmentCatalog.jsp">Equipment Catalog</a>
                <a href="RentingStatus.jsp">Renting Status</a>
                <a href="Transaction.jsp">Transaction</a>
                <a href="CustomerProfile.jsp">Profile</a>
                <br><br><br><br>
                <a href="LogoutServlet">Logout</a>
            </div>
        </div>
        <div class="profile">
            <div class="avatar"></div>
            <div>
                <h3><%=customer.getUserName()%></h3>
                <p style="color:#999;">Customer</p>
            </div>
        </div>
    </div>

    <div class="main">
        <div class="welcome">
            <h1>Your Cart</h1>
            <p>Review your selected equipment before checkout.</p>
        </div>

        <%
        if(cartError != null){
        %>
        <p style="color:red;"><%=cartError%></p>
        <%
        }
        %>

        <div class="dashboard-card">
            <div class="past-rental" style="width:100%;">
                <table>
                    <tr>
                        <th>Name</th>
                        <th>Qty</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Days</th>
                        <th>Price / Day</th>
                        <th>Subtotal</th>
                        <th>Action</th>
                    </tr>
                    <%
                    double total = 0;

                    if(cartItems != null && !cartItems.isEmpty()){
                        for(Cart item : cartItems){

                            long days = ((item.getEndDate().getTime()
                                    - item.getStartDate().getTime())
                                    / (1000 * 60 * 60 * 24)) + 1;
                            if(days < 1){
                                days = 1;
                            }

                            double subtotal = item.getPricePerDay() * item.getQuantity() * days;
                            total += subtotal;
                    %>
                    <tr>
                        <td><%=item.getEquipmentName()%></td>
                        <td><%=item.getQuantity()%></td>
                        <td><%=item.getStartDate()%></td>
                        <td><%=item.getEndDate()%></td>
                        <td><%=days%></td>
                        <td>RM <%=String.format("%.2f", item.getPricePerDay())%></td>
                        <td>RM <%=String.format("%.2f", subtotal)%></td>
                        <td>
                            <a href="RemoveFromCartServlet?cartID=<%=item.getCartID()%>">
                                Remove
                            </a>
                        </td>
                    </tr>
                    <%
                        }
                    } else {
                    %>
                    <tr>
                        <td colspan="8" align="center">
                            Your cart is empty.
                        </td>
                    </tr>
                    <%
                    }
                    %>
                </table>

                <h3>Total : RM <%=String.format("%.2f", total)%></h3>
            </div>
        </div>

        <div class="button-container">
            <div class="rent-now">
                <a href="EquipmentCatalog.jsp">Continue Shopping</a>
            </div>
            <%
            if(cartItems != null && !cartItems.isEmpty()){
            %>
            <form action="CheckoutServlet" method="post" style="display:inline;">
                <input type="submit" value="Checkout" class="btn-checkout">
            </form>
            <%
            }
            %>
        </div>
    </div>
</div>
</body>
</html>
