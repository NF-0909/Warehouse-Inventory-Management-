<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="dao.EquipmentDAO"%>
<%@page import="bean.Equipment"%>
<%@page import="java.util.ArrayList"%>
<%@page import="bean.Customer"%>

<%
Customer customer = (Customer)session.getAttribute("customer");

if(customer == null){

    response.sendRedirect("login.jsp");
    return;

}
%>
<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <title>Equipment Catalog</title>

    <link rel="stylesheet" href="css/style.css">

    <style>
        .equip-thumb{
            width:48px;
            height:48px;
            border-radius:8px;
            object-fit:cover;
            background:#151517;
            display:block;
        }
        .equip-thumb-placeholder{
            width:48px;
            height:48px;
            border-radius:8px;
            background:#151517;
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:20px;
        }
    </style>

</head>

<body>

<div class="sidebar">

    <!-- SIDEBAR -->

    <div class="sidebar-items">

        <div>

            <div class="logo">
                <a href="dashboard.jsp">
                    Equipment Rental System
                </a>
            </div>

            <div class="menu">

                <a href="dashboard.jsp">Dashboard</a>

                <a href="EquipmentCatalog.jsp">
                    Equipment Catalog
                </a>

                <a href="RentingStatus.jsp">
                    Renting Status
                </a>

                <a href="Transaction.jsp">
                    Transaction
                </a>

                <a href="CustomerProfile.jsp">
                    Profile
                </a>

                <br><br><br><br>

                <a href="LogoutServlet">
                    Logout
                </a>

            </div>

        </div>

        <div class="profile">

            <div class="avatar"></div>

            <div>
                <h3><%=customer.getUserName()%></h3>
                <p style="color:#999;">Customer</p>
            </div>

        </div>

    </div>

    <!-- MAIN CONTENT -->

    <div class="main">

        <div class="welcome">

            <h1>Equipment Catalog</h1>

            <p>Available equipment for rental.</p>

        </div>

        <%
        String cartError = (String) session.getAttribute("cartError");
        session.removeAttribute("cartError");
        if(cartError != null){
        %>
        <p style="color:red;"><%=cartError%></p>
        <%
        }
        %>

        <div class="dashboard-card">

            <div class="past-rental" style="width:100%;">

                <h3>Equipment List</h3>
                   <%
                    EquipmentDAO dao = new EquipmentDAO();
                    String keyword =
                    request.getParameter("keyword");
                    ArrayList<Equipment> list;
                    if(keyword != null && !keyword.trim().equals("")){

                        list = dao.searchEquipment(keyword);
                    }else{

                        list = dao.getAllEquipment();
                    }
                   %>
                   <form action="EquipmentCatalog.jsp" method="get"
                    style="margin-bottom:20px;">

                        <input type="text"
                               name="keyword"
                               placeholder="Search equipment..."
                               value="<%=keyword == null ? "" : keyword%>"
                               style="padding:8px;width:250px;">

                        <input type="submit"
                               value="Search"
                               style="padding:8px 15px;">

                        <a href="EquipmentCatalog.jsp">
                            <button type="button">
                                Reset
                            </button>
                        </a>

                    </form>
                 <table>

                    <tr>
                        <th>ID</th>
                        <th>Image</th>
                        <th>Equipment</th>
                        <th>Category</th>
                        <th>Status</th>
                        <th>Price/Day</th>
                        <th>Action</th>
                    </tr>

                    <%
                    for(Equipment e : list){
                    %>

                    <tr>

                        <td><%=e.getEquipmentID()%></td>
                        <td>
                    <%
                        String catImg = e.getImagePath();
                        if(catImg != null && !catImg.trim().equals("")){
                    %>
                        <img src="<%=catImg%>" alt="<%=e.getEquipmentName()%>" class="equip-thumb">
                    <%
                        }else{
                    %>
                        <div class="equip-thumb-placeholder">&#128230;</div>
                    <%
                        }
                    %>
                        </td>
                        <td><%=e.getEquipmentName()%></td>
                        <td><%=e.getEquipmentType()%></td>
                        <td>
                    <%
                        if(e.isAvailabilityStatus()){
                    %>
                        <span style="color:limegreen;font-weight:bold;">
                             Available
                        </span>
                    <%
                        }else{
                    %>
                        <span style="color:red;font-weight:bold;">
                            Unavailable
                        </span>
                    <%
                    }
                    %>
                        </td>
                        <td>RM <%=String.format("%.2f", e.getPricePerDay())%></td>
                        <td>
                    <%
                        if(e.isAvailabilityStatus()){
                    %>

                    <form action="AddToCartServlet" method="post"
                          style="display:flex;gap:5px;align-items:center;flex-wrap:wrap;">

                    <input type="hidden"
                            name="equipmentID"
                            value="<%=e.getEquipmentID()%>">

                    <input type="number"
                           name="quantity"
                           value="1"
                           min="1"
                           style="width:55px;"
                           required>

                    <input type="date"
                           name="startDate"
                           required>

                    <input type="date"
                           name="endDate"
                           required>

                    <input type="submit"
                           value="Add to Cart">

                    </form>

                    <%
                    }else{
                    %>

                    <button disabled>Unavailable</button>

                    <%
                    }
                    %>

                    </td>

                    </tr>

                    <%
                    }
                    %>

                </table>

            </div>

        </div>

        <div class="button-container">

            <div class="rent-now">

                <a href="Cart.jsp">
                    View Cart
                </a>

            </div>

        </div>

    </div>

</div>

</body>
</html>