<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="dao.EquipmentDAO"%>
<%@page import="bean.Equipment"%>
<%@page import="bean.Employee"%>
<%@page import="java.util.ArrayList"%>

<%
    Employee employee = (Employee) session.getAttribute("employee");

    if(employee == null){
        response.sendRedirect("login.jsp");
        return;
    }

    EquipmentDAO dao = new EquipmentDAO();
    ArrayList<Equipment> list = dao.getAllEquipment();
%>

<!DOCTYPE html>

<html>

<head>

    <meta charset="UTF-8">

    <title>Equipment Management</title>

    <link rel="stylesheet" href="css/style.css">

    <style>

        body
        {
            background-color: #0f172a;
            color: white;
        }

        .main
        {
            padding: 40px;
        }

        .welcome h1
        {
            font-size: 2.5rem;
            margin-bottom: 5px;
            color: white;
        }

        .welcome p
        {
            color: #94a3b8;
            margin-bottom: 30px;
        }

        .content-container
        {
            background-color: #1e293b;
            border-radius: 15px;
            padding: 30px;
            max-width: 1100px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        }

        .section-header
        {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .section-title
        {
            color: white;
            font-size: 1.3rem;
            font-weight: 600;
        }

        .btn-add
        {
            background-color: #10b981;
            color: white;
            text-decoration: none;
            padding: 10px 18px;
            border-radius: 8px;
            font-weight: bold;
        }

        .btn-add:hover
        {
            background-color: #059669;
        }

        .data-table
        {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th
        {
            background-color: #0f172a;
            color: #94a3b8;
            padding: 15px;
            text-align: left;
        }

        .data-table td
        {
            padding: 15px;
            border-bottom: 1px solid #334155;
        }

        .btn-edit
        {
            background-color: #3b82f6;
            color: white;
            text-decoration: none;
            padding: 8px 14px;
            border-radius: 6px;
            margin-right: 8px;
        }

        .btn-edit:hover
        {
            background-color: #2563eb;
        }

        .btn-delete
        {
            background-color: #ef4444;
            color: white;
            text-decoration: none;
            padding: 8px 14px;
            border-radius: 6px;
        }

        .btn-delete:hover
        {
            background-color: #dc2626;
        }

        .available
        {
            color: #10b981;
            font-weight: bold;
        }

        .unavailable
        {
            color: #ef4444;
            font-weight: bold;
        }

        .equip-thumb
        {
            width: 48px;
            height: 48px;
            border-radius: 8px;
            object-fit: cover;
            background: #0f172a;
            display: block;
        }

        .equip-thumb-placeholder
        {
            width: 48px;
            height: 48px;
            border-radius: 8px;
            background: #0f172a;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

    </style>

</head>

<body>

<div class="sidebar">

    <div class="sidebar-items">

        <div>

            <div class="logo">

                <a href="employeeDashboard.jsp">

                    Equipment Rental System

                </a>

            </div>

                        <div class="menu">
                <a href="employeeDashboard.jsp">Dashboard</a>
                <a href="EquipmentList.jsp">Equipment List</a>
                <a href="pendingRentals.jsp">Pending Rentals</a>
                <a href="maintenanceList.jsp">Maintenance List</a>
                <a href="maintenanceHistory.jsp">Maintenance History</a>
                <a href="EmployeeProfile.jsp">Profile</a>
                <br><br><br><br>
                <a href="LogoutServlet">Logout</a>
            </div>

        </div>

                <div class="profile">
            <div class="avatar" style="background: linear-gradient(135deg, #10b981, #047857);">E</div>
            <div>
                <h3><%= employee.getEmployeeName() %></h3>
                <p style="color:#999;"><%= employee.getPosition() %></p>
            </div>
        </div>

    </div>

    <div class="main">

        <div class="welcome">

            <h1>Equipment Management</h1>

            <p>

                Manage all rental equipment available in the system.

            </p>

        </div>

        <div class="content-container">

            <div class="section-header">

                <h3 class="section-title">

                    Equipment Inventory

                </h3>

                <a href="AddEquipment.jsp"
                   class="btn-add">

                    + Add Equipment

                </a>

            </div>

            <table class="data-table">

                <thead>

                    <tr>

                        <th>ID</th>

                        <th>Image</th>

                        <th>Name</th>

                        <th>Type</th>

                        <th>Condition</th>

                        <th>Price / Day</th>

                        <th>Status</th>

                        <th>Action</th>

                    </tr>

                </thead>

                <tbody>

                <%

                    for(Equipment e : list)
                    {

                %>

                    <tr>

                        <td>

                            <%=e.getEquipmentID()%>

                        </td>

                        <td>

                            <%
                                String listImg = e.getImagePath();
                                if(listImg != null && !listImg.trim().equals(""))
                                {
                            %>
                                <img src="<%=listImg%>" alt="<%=e.getEquipmentName()%>" class="equip-thumb">
                            <%
                                }
                                else
                                {
                            %>
                                <div class="equip-thumb-placeholder">&#128230;</div>
                            <%
                                }
                            %>

                        </td>

                        <td>

                            <%=e.getEquipmentName()%>

                        </td>

                        <td>

                            <%=e.getEquipmentType()%>

                        </td>

                        <td>

                            <%=e.getConditionStatus()%>

                        </td>

                        <td>

                            RM <%=String.format("%.2f",
                                    e.getPricePerDay())%>

                        </td>

                        <td>

                            <%

                                if(e.isAvailabilityStatus())
                                {

                            %>

                                <span class="available">

                                    Available

                                </span>

                            <%

                                }
                                else
                                {

                            %>

                                <span class="unavailable">

                                    Unavailable

                                </span>

                            <%

                                }

                            %>

                        </td>

                        <td>

                            <a href="EditEquipment.jsp?id=<%=e.getEquipmentID()%>"
                               class="btn-edit">

                                Edit

                            </a>

                            <a href="DeleteEquipmentServlet?id=<%=e.getEquipmentID()%>"
                               class="btn-delete"
                               onclick="return confirm('Delete this equipment?');">

                                Delete

                            </a>

                        </td>

                    </tr>

                <%

                    }

                %>

                </tbody>

            </table>

        </div>

    </div>

</div>

</body>

</html>