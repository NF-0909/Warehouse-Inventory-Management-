<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="bean.Customer"%>

<%
    Customer customer = (Customer) session.getAttribute("customer");

    if (customer == null) {

        response.sendRedirect("login.jsp");
        return;

    }
%>

<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">

    <title>Customer Profile</title>

    <link rel="stylesheet" href="css/style.css">

    <style>

        body {

            background-color: #0f172a;
            color: white;

        }

        .main {

            padding: 40px;

        }

        .welcome h1 {

            font-size: 2.5rem;
            margin-bottom: 5px;
            color: #ffffff;

        }

        .welcome p {

            color: #94a3b8;
            margin-bottom: 30px;

        }

        .profile-container {

            background-color: #1e293b;
            border-radius: 15px;
            padding: 40px;
            max-width: 900px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);

        }

        .avatar-section {

            text-align: center;
            margin-bottom: 30px;
            border-bottom: 1px solid #334155;
            padding-bottom: 20px;

        }

        .big-avatar {

            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            border-radius: 50%;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            color: white;
            border: 4px solid #334155;

        }

        .username-display {

            font-size: 1.5rem;
            font-weight: 600;
            color: #f8fafc;

        }

        .section-title {

            color: #94a3b8;
            font-size: 1.2rem;
            margin-bottom: 25px;
            font-weight: 500;

        }

        .info-group {

            margin-bottom: 25px;
            border-bottom: 1px solid #334155;
            padding-bottom: 10px;

        }

        .info-group label {

            display: block;
            color: #94a3b8;
            font-size: 0.9rem;
            margin-bottom: 5px;
            text-transform: uppercase;
            letter-spacing: 0.5px;

        }

        .info-value {

            font-size: 1.1rem;
            color: #f8fafc;
            font-weight: 500;

        }

        .btn-edit {

            display: inline-block;
            background-color: #3b82f6;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s;

        }

        .btn-edit:hover {

            background-color: #2563eb;

        }

        .modal-overlay {

            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(5px);
            z-index: 1000;
            justify-content: center;
            align-items: center;

        }

        .modal-content {

            background-color: #1e293b;
            border-radius: 15px;
            padding: 40px;
            width: 90%;
            max-width: 550px;

        }

        .form-group {

            margin-bottom: 20px;

        }

        .form-group label {

            display: block;
            margin-bottom: 8px;
            color: #94a3b8;

        }

        .form-group input {

            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: none;
            font-size: 1rem;
            box-sizing: border-box;

        }

        .btn-container {

            display: flex;
            gap: 15px;
            margin-top: 20px;

        }

        .btn-update {

            background: #3b82f6;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            cursor: pointer;

        }

        .btn-cancel {

            background: #475569;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            cursor: pointer;

        }

    </style>

</head>

<body>

<div class="sidebar">

    <div class="sidebar-items">

        <div>

            <div class="logo">

                <a href="dashboard.jsp">
                    Equipment Rental System
                </a>

            </div>

            <div class="menu">

                <a href="dashboard.jsp">
                    Dashboard
                </a>

                <a href="EquipmentCatalog.jsp">
                    Equipment Catalog
                </a>

                <a href="RentingStatus.jsp">
                    Renting Status
                </a>

                <a href="Transaction.jsp">
                    Transaction
                </a>

                <a href="CustomerProfile.jsp">
                    Profile
                </a>

                <br><br><br><br>

                <a href="LogoutServlet">
                    Logout
                </a>

            </div>

        </div>

        <div class="profile">

            <div class="avatar"></div>

            <div>

                <h3>
                    <%= customer.getUserName() %>
                </h3>

                <p style="color:#999;">
                    Customer
                </p>

            </div>

        </div>

    </div>

    <div class="main">
                <div class="welcome">

            <h1>
                My Profile
            </h1>

            <p>
                View and update your personal information.
            </p>

        </div>

        <div class="profile-container">

            <div class="avatar-section">

                <div class="big-avatar">

                    <%= customer.getUserName().substring(0, 1).toUpperCase() %>

                </div>

                <div class="username-display">

                    <%= customer.getUserName() %>

                </div>

            </div>

            <h3 class="section-title">
                Profile Information
            </h3>

            <div class="info-group">

                <label>
                    Username
                </label>

                <div class="info-value">

                    <%= customer.getUserName() %>

                </div>

            </div>

            <div class="info-group">

                <label>
                    Email Address
                </label>

                <div class="info-value">

                    <%= customer.getEmail() %>

                </div>

            </div>

            <div class="info-group">

                <label>
                    Role
                </label>

                <div class="info-value">

                    Customer

                </div>

            </div>

            <div class="info-group">

                <label>
                    Password
                </label>

                <div class="info-value">

                    ••••••••

                </div>

            </div>

            <button
                type="button"
                class="btn-edit"
                onclick="openModal()">

                Edit Profile

            </button>

        </div>

    </div>

</div>

<!-- ===================== -->
<!-- EDIT PROFILE POPUP -->
<!-- ===================== -->

<div
    id="editProfileModal"
    class="modal-overlay"
    onclick="closeModalOutside(event)">

    <div class="modal-content">

        <div class="welcome" style="margin-top:0;">

            <h1 style="font-size:2rem;">
                Edit Profile
            </h1>

            <p>
                Update your account information.
            </p>

        </div>

        <form
            action="UpdateCustomerProfileServlet"
            method="post">

            <div class="form-group">

                <label>
                    Username
                </label>

                <input
                    type="text"
                    name="username"
                    value="<%= customer.getUserName() %>"
                    required>

            </div>

            <div class="form-group">

                <label>
                    Email Address
                </label>

                <input
                    type="email"
                    name="email"
                    value="<%= customer.getEmail() %>"
                    required>

            </div>

            <div class="form-group">

                <label>
                    New Password
                </label>

                <input
                    type="password"
                    name="password"
                    placeholder="Leave blank to keep current password">

            </div>

            <div class="btn-container">

                <button
                    type="submit"
                    class="btn-update">

                    Save Changes

                </button>

                <button
                    type="button"
                    class="btn-cancel"
                    onclick="closeModal()">

                    Cancel

                </button>

            </div>

        </form>
        <%
        if(request.getParameter("success") != null){
        %>
        <p style="color:limegreen;">
            Profile updated successfully.
        </p>
        <%
        }
        if(request.getParameter("error") != null){
        %>
        <p style="color:red;">
            Failed to update profile.
        </p>
        <%
        }
        %>
    </div>

</div>
<script>

    const modal =
    document.getElementById("editProfileModal");

    function openModal() {

        modal.style.display = "flex";

    }

    function closeModal() {

        modal.style.display = "none";

    }

    function closeModalOutside(event) {

        if(event.target === modal) {

            closeModal();

        }

    }

</script>

</body>

</html>