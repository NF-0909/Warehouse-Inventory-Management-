<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%@page import="dao.MaintenanceDAO"%>
<%@page import="bean.Maintenance"%>
<%@page import="bean.Employee"%>
<%@page import="java.util.ArrayList"%>


<%
    Employee employee =
            (Employee) session.getAttribute("employee");


    if(employee == null){

        response.sendRedirect("login.jsp");
        return;

    }


    MaintenanceDAO dao =
            new MaintenanceDAO();


    ArrayList<Maintenance> list =
            dao.getActiveMaintenance();

%>



<!DOCTYPE html>

<html>

<head>

    <meta charset="UTF-8">

    <title>
        Maintenance List
    </title>


    <link rel="stylesheet" href="css/style.css">


    <style>

        body {

            background-color: #0f172a;
            color: white;

        }


        .main {

            padding: 40px;

        }


        .welcome h1 {

            font-size: 2.5rem;
            margin-bottom: 5px;
            color: white;

        }


        .welcome p {

            color: #94a3b8;
            margin-bottom: 30px;

        }


        .content-container {

            background-color: #1e293b;

            border-radius: 15px;

            padding: 30px;

            max-width: 1100px;

            box-shadow:
                0 10px 25px rgba(0,0,0,0.3);

        }


        .section-header {

            display: flex;

            justify-content: space-between;

            align-items: center;

            margin-bottom: 25px;

        }


        .section-title {

            color: white;

            font-size: 1.3rem;

            font-weight: 600;

        }


        .search-box {

            padding: 10px 15px;

            width: 250px;

            background-color: #0f172a;

            border: 1px solid #334155;

            border-radius: 8px;

            color: white;

        }


        .data-table {

            width: 100%;

            border-collapse: collapse;

        }


        .data-table th {

            background-color: #0f172a;

            color: #94a3b8;

            padding: 14px;

            text-align: left;

        }


        .data-table td {

            padding: 16px;

            border-bottom: 1px solid #334155;

            color: #f8fafc;

        }


        .badge {

            display: inline-block;

            padding: 5px 12px;

            border-radius: 20px;

            font-size: 0.8rem;

            font-weight: 600;

        }


        .pending {

            background-color:
                rgba(245,158,11,0.15);

            color:
                #f59e0b;

        }


        .progress {

            background-color:
                rgba(59,130,246,0.15);

            color:
                #3b82f6;

        }


        .completed {

            background-color:
                rgba(16,185,129,0.15);

            color:
                #10b981;

        }


        .btn-action {

            background-color: #3b82f6;

            color: white;

            padding: 8px 16px;

            border-radius: 6px;

            text-decoration: none;

        }


        .btn-action:hover {

            background-color: #2563eb;

        }


        .empty-message {

            text-align: center;

            color: #94a3b8;

        }


    </style>


</head>


<body>



<div class="sidebar">


    <div class="sidebar-items">


        <div>


            <div class="logo">

                <a href="employeeDashboard.jsp">

                    Equipment Rental System

                </a>

            </div>



                        <div class="menu">
                <a href="employeeDashboard.jsp">Dashboard</a>
                <a href="EquipmentList.jsp">Equipment List</a>
                <a href="pendingRentals.jsp">Pending Rentals</a>
                <a href="maintenanceList.jsp">Maintenance List</a>
                <a href="maintenanceHistory.jsp">Maintenance History</a>
                <a href="EmployeeProfile.jsp">Profile</a>
                <br><br><br><br>
                <a href="LogoutServlet">Logout</a>
            </div>


        </div>



                <div class="profile">
            <div class="avatar" style="background: linear-gradient(135deg, #10b981, #047857);">E</div>
            <div>
                <h3><%= employee.getEmployeeName() %></h3>
                <p style="color:#999;"><%= employee.getPosition() %></p>
            </div>
        </div>


    </div>





    <div class="main">


        <div class="welcome">


            <h1>

                Maintenance Tasks

            </h1>


            <p>

                Manage pending assignments and update equipment service records.

            </p>


        </div>





        <div class="content-container">



            <div class="section-header">


                <h3 class="section-title">

                    Active Maintenance Queue

                </h3>



                <input type="text"
                       class="search-box"
                       placeholder="Search equipment...">


            </div>





            <table class="data-table">


                <thead>


                    <tr>

                        <th>
                            Task ID
                        </th>


                        <th>
                            Equipment
                        </th>


                        <th>
                            Issue
                        </th>


                        <th>
                            Status
                        </th>


                        <th>
                            Action
                        </th>


                    </tr>


                </thead>



                <tbody>



                <%

                    if(list.isEmpty()){


                %>


                    <tr>


                        <td colspan="5"
                            class="empty-message">

                            No maintenance records found.

                        </td>


                    </tr>


                <%

                    }

                    else{


                        for(Maintenance m : list){


                            String badgeClass = "pending";


                            if(m.getStatus().equalsIgnoreCase("Completed")){

                                badgeClass = "completed";

                            }
                            else if(m.getStatus().equalsIgnoreCase("In Progress")){

                                badgeClass = "progress";

                            }


                %>


                    <tr>


                        <td>

                            <%=m.getMaintenanceID()%>

                        </td>



                        <td>

                            <%=m.getEquipmentName()%>

                        </td>



                        <td>

                            <%=m.getIssue()%>

                        </td>



                        <td>


                            <span class="badge <%=badgeClass%>">

                                <%=m.getStatus()%>

                            </span>


                        </td>



                        <td>


                            <a href="updateMaintenance.jsp?id=<%=m.getMaintenanceID()%>"
                               class="btn-action">

                                Update

                            </a>


                        </td>


                    </tr>


                <%

                        }

                    }

                %>



                </tbody>


            </table>



        </div>



    </div>



</div>



</body>


</html>