<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="bean.Customer"%>
<%@page import="bean.Rental"%>
<%@page import="bean.Equipment"%>
<%@page import="dao.RentalsDAO"%>
<%@page import="dao.RentalsDAO.PopularEquipment"%>
<%@page import="dao.EquipmentDAO"%>
<%@page import="java.util.ArrayList"%>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Dashboard</title>

<link rel="stylesheet" href="css/style.css">

</head>

<body>
    <%

        Customer customer =
        (Customer)session.getAttribute("customer");

        if(customer==null){

         response.sendRedirect("login.jsp");

            return;

        }

        EquipmentDAO equipmentDAO = new EquipmentDAO();
        ArrayList<Equipment> equipmentList = equipmentDAO.getAllEquipment();

        int totalEquipment = equipmentList.size();
        int availableCount = 0;
        for(Equipment eq : equipmentList){
            if(eq.isAvailabilityStatus()){
                availableCount++;
            }
        }
        int rentedCount = totalEquipment - availableCount;

        RentalsDAO rentalsDAO = new RentalsDAO();
        ArrayList<Rental> recentRentals =
            rentalsDAO.getRentalsByCustomer(customer.getCustomerID());

        PopularEquipment popular = rentalsDAO.getMostRentedEquipment();

    %>

<div class="sidebar">

    <!-- LEFT SIDEBAR -->

    <div class="sidebar-items">

        <div>

            <div class="logo">
                <a href="dashboard.jsp">
                    Equipment Rental System
                </a>
            </div>

            <div class="menu">

                <a href="dashboard.jsp">Dashboard</a>

                <a href="EquipmentCatalog.jsp">
                    Equipment Catalog
                </a>

                <a href="RentingStatus.jsp">
                    Renting Status
                </a>

                <a href="Transaction.jsp">
                    Transaction
                </a>

                <a href="CustomerProfile.jsp">
                    Profile
                </a>

                <br><br><br><br>

                <a href="LogoutServlet">
                    Logout
                </a>

            </div>

        </div>

        <div class="profile">

            <div class="avatar"></div>

            <div>
                <h3><%= customer.getUserName() %></h3>
                <p style="color:#999;">
                Customer
                </p>
            </div>

        </div>

    </div>

    <!-- RIGHT CONTENT -->

    <div class="main">

        <div class="welcome">
            <h1>Welcome <%= customer.getUserName() %></h1>
            <p>Equipment Rental Management Dashboard</p>
        </div>

        <!-- STATISTICS -->

        <div class="stats">

            <div class="stat-card">
                <h2><%=totalEquipment%></h2>
                <p>Total Equipment</p>
            </div>

            <div class="stat-card">
                <h2><%=availableCount%></h2>
                <p>Available</p>
            </div>

            <div class="stat-card">
                <h2><%=rentedCount%></h2>
                <p>Currently Rented</p>
            </div>

            <div class="stat-card">
                <h2><%=recentRentals.size()%></h2>
                <p>Your Rentals</p>
            </div>

        </div>

        <!-- MAIN DASHBOARD -->

        <div class="dashboard-card">

            <div class="popular-items">

                <h3>Most Rented Equipment</h3>

                <%
                if(popular != null){
                    Equipment popularEquipment = popular.getEquipment();
                    String imgPath = popularEquipment.getImagePath();
                %>

                <div class="popular-image">
                    <%
                    if(imgPath != null && !imgPath.trim().equals("")){
                    %>
                        <img src="<%=imgPath%>" alt="<%=popularEquipment.getEquipmentName()%>">
                    <%
                    }else{
                    %>
                        <span style="font-size:3rem;">&#128230;</span>
                    <%
                    }
                    %>
                </div>

                <h4><%=popularEquipment.getEquipmentName()%></h4>

                <p>Total Rentals: <%=popular.getRentalCount()%> rental<%=popular.getRentalCount()==1 ? "" : "s"%></p>

                <%
                }else{
                %>

                <div class="popular-image">
                    <span style="font-size:3rem;">&#128230;</span>
                </div>

                <h4>No rentals yet</h4>

                <p>Popular equipment will appear here once rentals start coming in.</p>

                <%
                }
                %>

            </div>

            <div class="past-rental">

                <h3>Recent Rental History</h3>

                <table>

                    <thead>
                        <tr>
                            <th>Rental ID</th>
                            <th>Equipment</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody>

                    <%
                    int shown = 0;
                    for(Rental r : recentRentals){
                        if(shown >= 5) break;
                        shown++;
                    %>
                        <tr>
                            <td>#<%=r.getRentalID()%></td>
                            <td><%=r.getEquipmentName()%></td>
                            <td><%=r.getStartDate()%></td>
                            <td><%=r.getEndDate()==null ? "-" : r.getEndDate()%></td>
                            <td><%=r.getStatus()%></td>
                        </tr>
                    <%
                    }
                    if(recentRentals.isEmpty()){
                    %>
                        <tr>
                            <td colspan="5" align="center">No rentals yet.</td>
                        </tr>
                    <%
                    }
                    %>

                    </tbody>

                </table>

            </div>

        </div>

        <div class="button-container">

            <div class="rent-now">
                <a href="EquipmentCatalog.jsp">
                    Browse Equipment
                </a>
            </div>

        </div>

    </div>

</div>

</body>
</html>