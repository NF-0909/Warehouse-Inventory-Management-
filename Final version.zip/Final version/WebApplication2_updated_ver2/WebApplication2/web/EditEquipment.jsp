<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="bean.Employee"%>
<%@page import="bean.Equipment"%>
<%@page import="dao.EquipmentDAO"%>
<%
Employee employee =
(Employee)session.getAttribute("employee");

if(employee==null){
    response.sendRedirect("login.jsp");
    return;
}

String idParam = request.getParameter("id");
if(idParam == null){
    response.sendRedirect("EquipmentList.jsp");
    return;
}

int id = Integer.parseInt(idParam);
EquipmentDAO dao = new EquipmentDAO();
Equipment equipment = dao.getEquipmentByID(id);

if(equipment == null){
    response.sendRedirect("EquipmentList.jsp");
    return;
}
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edit Equipment</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body{
            background-color:#0f172a;
            color:white;
        }
        .main{
            padding:40px;
        }
        .welcome h1{
            font-size:2.5rem;
            margin-bottom:5px;
        }
        .welcome p{
            color:#94a3b8;
            margin-bottom:30px;
        }
        .form-container{
            background:#1e293b;
            max-width:700px;
            padding:35px;
            border-radius:15px;
            box-shadow:0 10px 25px rgba(0,0,0,.3);
        }
        .form-group{
            margin-bottom:20px;
        }
        .form-group label{
            display:block;
            margin-bottom:8px;
            color:#94a3b8;
        }
        .form-group input,
        .form-group select{
            width:100%;
            padding:12px;
            border-radius:8px;
            border:1px solid #334155;
            font-size:15px;
        }
        .btn-container{
            display:flex;
            gap:15px;
            margin-top:25px;
        }
        .btn-save{
            background:#3b82f6;
            color:white;
            border:none;
            padding:12px 28px;
            border-radius:8px;
            cursor:pointer;
        }
        .btn-save:hover{
            background:#2563eb;
        }
        .btn-cancel{
            background:#475569;
            color:white;
            padding:12px 28px;
            border-radius:8px;
            text-decoration:none;
        }
        .btn-cancel:hover{
            background:#334155;
        }
    </style>
</head>
<body>
<div class="sidebar">
    <div class="sidebar-items">
        <div>
            <div class="logo">
                <a href="employeeDashboard.jsp">
                    Equipment Rental System
                </a>
            </div>
                        <div class="menu">
                <a href="employeeDashboard.jsp">Dashboard</a>
                <a href="EquipmentList.jsp">Equipment List</a>
                <a href="pendingRentals.jsp">Pending Rentals</a>
                <a href="maintenanceList.jsp">Maintenance List</a>
                <a href="maintenanceHistory.jsp">Maintenance History</a>
                <a href="EmployeeProfile.jsp">Profile</a>
                <br><br><br><br>
                <a href="LogoutServlet">Logout</a>
            </div>
        </div>
                <div class="profile">
            <div class="avatar" style="background: linear-gradient(135deg, #10b981, #047857);">E</div>
            <div>
                <h3><%= employee.getEmployeeName() %></h3>
                <p style="color:#999;"><%= employee.getPosition() %></p>
            </div>
        </div>
    </div>

    <div class="main">
        <div class="welcome">
            <h1>Edit Equipment</h1>
            <p>Update details for this piece of equipment.</p>
        </div>

        <div class="form-container">
            <form action="EditEquipmentServlet" method="post" enctype="multipart/form-data">

                <input type="hidden" name="equipmentID" value="<%=equipment.getEquipmentID()%>">

                <div class="form-group">
                    <label>Equipment Name</label>
                    <input type="text" name="name"
                           value="<%=equipment.getEquipmentName()%>" required>
                </div>

                <div class="form-group">
                    <label>Equipment Type</label>
                    <input type="text" name="type"
                           value="<%=equipment.getEquipmentType()%>" required>
                </div>

                <div class="form-group">
                    <label>Condition</label>
                    <select name="condition">
                        <option value="Excellent" <%="Excellent".equals(equipment.getConditionStatus())?"selected":""%>>Excellent</option>
                        <option value="Good" <%="Good".equals(equipment.getConditionStatus())?"selected":""%>>Good</option>
                        <option value="Fair" <%="Fair".equals(equipment.getConditionStatus())?"selected":""%>>Fair</option>
                        <option value="Damaged" <%="Damaged".equals(equipment.getConditionStatus())?"selected":""%>>Damaged</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Price Per Day (RM)</label>
                    <input type="number" step="0.01" name="price"
                           value="<%=equipment.getPricePerDay()%>" required>
                </div>

                <div class="form-group">
                    <label>Availability</label>
                    <select name="available">
                        <option value="true" <%=equipment.isAvailabilityStatus()?"selected":""%>>Available</option>
                        <option value="false" <%=!equipment.isAvailabilityStatus()?"selected":""%>>Unavailable</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Current Image</label>
                    <%
                        String currentImg = equipment.getImagePath();
                        if(currentImg != null && !currentImg.trim().equals("")){
                    %>
                        <img src="<%=currentImg%>" alt="<%=equipment.getEquipmentName()%>"
                             style="max-width:150px;max-height:150px;border-radius:8px;display:block;margin-bottom:10px;">
                    <%
                        }else{
                    %>
                        <p style="color:#94a3b8;margin-bottom:10px;">No image uploaded yet.</p>
                    <%
                        }
                    %>
                    <label>Replace Image</label>
                    <input type="file" name="imageFile" accept="image/*">
                    <p style="color:#94a3b8;font-size:13px;margin-top:6px;">Leave empty to keep the current image.</p>
                </div>

                <div class="btn-container">
                    <button type="submit" class="btn-save">Save Changes</button>
                    <a href="EquipmentList.jsp" class="btn-cancel">Cancel</a>
                </div>

            </form>
        </div>
    </div>
</div>
</body>
</html>
