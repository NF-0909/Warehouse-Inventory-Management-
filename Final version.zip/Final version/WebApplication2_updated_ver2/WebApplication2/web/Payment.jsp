<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="bean.Customer"%>

<%
Customer customer = (Customer)session.getAttribute("customer");

if(customer == null){
    response.sendRedirect("login.jsp");
    return;
}

Double totalAmountObj = (Double) session.getAttribute("totalAmount");
double totalAmount = (totalAmountObj != null) ? totalAmountObj : 0.0;
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Payment</title>
    <link rel="stylesheet" href="css/style.css">
    <style>

        .payment-layout{
            display:flex;
            gap:25px;
            align-items:flex-start;
            flex-wrap:wrap;
        }

        .payment-form-card{
            flex:2;
            min-width:340px;
            background:#1f1f1f;
            border-radius:20px;
            padding:30px;
            box-shadow:0 10px 25px rgba(0,0,0,0.25);
        }

        .payment-form-card h3{
            margin-bottom:20px;
            font-size:1.2rem;
            color:#f8fafc;
        }

        .method-group{
            display:flex;
            flex-direction:column;
            gap:14px;
            margin-bottom:10px;
        }

        .method-option{
            position:relative;
        }

        .method-option input[type="radio"]{
            position:absolute;
            opacity:0;
            width:100%;
            height:100%;
            margin:0;
            cursor:pointer;
        }

        .method-option label{
            display:flex;
            align-items:center;
            gap:15px;
            background:#151517;
            border:2px solid rgba(255,255,255,0.08);
            border-radius:14px;
            padding:16px 18px;
            cursor:pointer;
            transition:border-color 0.2s, background 0.2s;
        }

        .method-option label:hover{
            border-color:#3b82f6;
        }

        .method-option input[type="radio"]:checked + label{
            border-color:#3b82f6;
            background:rgba(59,130,246,0.12);
        }

        .method-icon{
            width:42px;
            height:42px;
            min-width:42px;
            border-radius:12px;
            background:#242428;
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:20px;
        }

        .method-text strong{
            display:block;
            color:#f8fafc;
            font-size:1rem;
        }

        .method-text span{
            display:block;
            color:#94a3b8;
            font-size:0.85rem;
            margin-top:2px;
        }

        .btn-row{
            display:flex;
            gap:15px;
            margin-top:25px;
        }

        .btn-confirm{
            flex:1;
            background:#3b82f6;
            color:white;
            border:none;
            padding:15px 25px;
            border-radius:12px;
            font-size:1rem;
            font-weight:600;
            cursor:pointer;
            transition:background 0.2s;
        }

        .btn-confirm:hover{
            background:#2563eb;
        }

        .btn-back{
            background:#2a2a2a;
            color:#e2e8f0;
            border:none;
            padding:15px 25px;
            border-radius:12px;
            font-size:1rem;
            font-weight:600;
            cursor:pointer;
            text-decoration:none;
            display:flex;
            align-items:center;
            justify-content:center;
            transition:background 0.2s;
        }

        .btn-back:hover{
            background:#3a3a3a;
        }

        .summary-card{
            flex:1;
            min-width:280px;
            background:#1f1f1f;
            border-radius:20px;
            padding:30px;
            box-shadow:0 10px 25px rgba(0,0,0,0.25);
        }

        .summary-card h3{
            font-size:1.1rem;
            color:#f8fafc;
            margin-bottom:20px;
        }

        .summary-row{
            display:flex;
            justify-content:space-between;
            padding:10px 0;
            color:#94a3b8;
            border-bottom:1px solid rgba(255,255,255,0.08);
        }

        .summary-row.total{
            color:#f8fafc;
            font-size:1.25rem;
            font-weight:700;
            border-bottom:none;
            padding-top:18px;
        }

        .secure-note{
            margin-top:20px;
            display:flex;
            align-items:center;
            gap:10px;
            color:#64748b;
            font-size:0.8rem;
        }

    </style>
</head>
<body>

<div class="sidebar">

    <div class="sidebar-items">
        <div>
            <div class="logo">
                <a href="dashboard.jsp">Equipment Rental System</a>
            </div>

            <div class="menu">
                <a href="dashboard.jsp">Dashboard</a>
                <a href="EquipmentCatalog.jsp">Equipment Catalog</a>
                <a href="RentingStatus.jsp">Renting Status</a>
                <a href="Transaction.jsp">Transaction</a>
                <a href="CustomerProfile.jsp">Profile</a>
                <br><br><br><br>
                <a href="LogoutServlet">Logout</a>
            </div>
        </div>

        <div class="profile">
            <div class="avatar"></div>
            <div>
                <h3><%=customer.getUserName()%></h3>
                <p style="color:#999;">Customer</p>
            </div>
        </div>
    </div>

    <div class="main">

        <div class="welcome">
            <h1>Payment</h1>
            <p>Choose a payment method to complete your checkout.</p>
        </div>

        <form action="PaymentServlet" method="post">

            <div class="payment-layout">

                <div class="payment-form-card">

                    <h3>Select Payment Method</h3>

                    <div class="method-group">

                        <div class="method-option">
                            <input type="radio" id="methodCash" name="paymentMethod" value="Cash" checked>
                            <label for="methodCash">
                                <div class="method-icon">&#128181;</div>
                                <div class="method-text">
                                    <strong>Cash</strong>
                                    <span>Pay in person upon pickup</span>
                                </div>
                            </label>
                        </div>

                        <div class="method-option">
                            <input type="radio" id="methodCard" name="paymentMethod" value="Card">
                            <label for="methodCard">
                                <div class="method-icon">&#128179;</div>
                                <div class="method-text">
                                    <strong>Credit / Debit Card</strong>
                                    <span>Visa, Mastercard and more</span>
                                </div>
                            </label>
                        </div>

                        <div class="method-option">
                            <input type="radio" id="methodOnline" name="paymentMethod" value="Online Banking">
                            <label for="methodOnline">
                                <div class="method-icon">&#127974;</div>
                                <div class="method-text">
                                    <strong>Online Banking</strong>
                                    <span>Pay directly from your bank</span>
                                </div>
                            </label>
                        </div>

                    </div>

                    <div class="btn-row">
                        <a href="Cart.jsp" class="btn-back">Back to Cart</a>
                        <button type="submit" class="btn-confirm">Confirm Payment</button>
                    </div>

                </div>

                <div class="summary-card">
                    <h3>Order Summary</h3>

                    <div class="summary-row">
                        <span>Subtotal</span>
                        <span>RM <%=String.format("%.2f", totalAmount)%></span>
                    </div>

                    <div class="summary-row total">
                        <span>Total</span>
                        <span>RM <%=String.format("%.2f", totalAmount)%></span>
                    </div>

                    <div class="secure-note">
                        &#128274; Your payment is processed securely.
                    </div>
                </div>

            </div>

        </form>

    </div>

</div>

</body>
</html>
