package dao;

import bean.Payment;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import util.DBConnection;

public class PaymentDAO {

    public boolean addPayment(int rentalID,
                              double amount,
                              String method){

        boolean success = false;

        try{

            Connection conn =
            DBConnection.getConnection();

            String sql =
"INSERT INTO Payments(RentalID,Amount,PaymentDate,PaymentMethod) VALUES(?,?,CURRENT_DATE,?)";

            PreparedStatement ps =
            conn.prepareStatement(sql);

            ps.setInt(1,rentalID);
            ps.setDouble(2,amount);
            ps.setString(3,method);

            success =
            ps.executeUpdate()>0;

            conn.close();

        }catch(Exception e){

            e.printStackTrace();

        }

        return success;

    }
public ArrayList<Payment> getPaymentsByRental(int rentalID){

    ArrayList<Payment> list = new ArrayList<>();

    try{

        Connection conn = DBConnection.getConnection();

        String sql =
        "SELECT * FROM Payments WHERE RentalID=?";

        PreparedStatement ps =
                conn.prepareStatement(sql);

        ps.setInt(1, rentalID);

        ResultSet rs = ps.executeQuery();

        while(rs.next()){

            Payment p = new Payment();

            p.setPaymentID(rs.getInt("PaymentID"));
            p.setRentalID(rs.getInt("RentalID"));
            p.setAmount(rs.getDouble("Amount"));
            p.setPaymentDate(rs.getDate("PaymentDate"));
            p.setPaymentMethod(rs.getString("PaymentMethod"));

            list.add(p);

        }

        conn.close();

    }catch(Exception e){

        e.printStackTrace();

    }

    return list;

}
public ArrayList<Payment> getPaymentsByCustomer(int customerID){
    ArrayList<Payment> list = new ArrayList<>();
    try{
        Connection conn = DBConnection.getConnection();
        String sql =
        "SELECT p.*, e.EquipmentName FROM Payments p " +
        "JOIN Rentals r ON p.RentalID = r.RentalID " +
        "JOIN Equipment e ON r.EquipmentID = e.EquipmentID " +
        "WHERE r.CustomerID=? ORDER BY p.PaymentID DESC";
        PreparedStatement ps =
                conn.prepareStatement(sql);
        ps.setInt(1, customerID);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            Payment p = new Payment();
            p.setPaymentID(rs.getInt("PaymentID"));
            p.setRentalID(rs.getInt("RentalID"));
            p.setAmount(rs.getDouble("Amount"));
            p.setPaymentDate(rs.getDate("PaymentDate"));
            p.setPaymentMethod(rs.getString("PaymentMethod"));
            p.setEquipmentName(rs.getString("EquipmentName"));
            list.add(p);
        }
        rs.close();
        ps.close();
        conn.close();
    }catch(Exception e){
        e.printStackTrace();
    }
    return list;
}

public double getTotalRevenue(){

    double revenue = 0;

    try{

        Connection conn =
        DBConnection.getConnection();

        String sql =
        "SELECT SUM(Amount) FROM Payments";

        PreparedStatement ps =
        conn.prepareStatement(sql);

        ResultSet rs =
        ps.executeQuery();

        if(rs.next()){

            revenue = rs.getDouble(1);

        }

        conn.close();

    }catch(Exception e){

        e.printStackTrace();

    }

    return revenue;

}
public ArrayList<Payment> getAllPayments(){

    ArrayList<Payment> list = new ArrayList<>();

    try{

        Connection conn = DBConnection.getConnection();

        String sql =
        "SELECT * FROM Payments";

        PreparedStatement ps =
        conn.prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        while(rs.next()){

            Payment p = new Payment();

            p.setPaymentID(rs.getInt("PaymentID"));
            p.setRentalID(rs.getInt("RentalID"));
            p.setAmount(rs.getDouble("Amount"));
            p.setPaymentDate(rs.getDate("PaymentDate"));
            p.setPaymentMethod(rs.getString("PaymentMethod"));

            list.add(p);

        }

        rs.close();
        ps.close();
        conn.close();

    }catch(Exception e){

        e.printStackTrace();

    }

    return list;

}
}
