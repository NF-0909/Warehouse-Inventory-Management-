package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import bean.Equipment;
import util.DBConnection;


public class EquipmentDAO {


    // ============================
    // GET ALL EQUIPMENT
    // ============================
    public ArrayList<Equipment> getAllEquipment(){


        ArrayList<Equipment> list =
        new ArrayList<>();


        String sql =
        "SELECT * FROM Equipment ORDER BY EquipmentID";



        try{


            Connection conn =
            DBConnection.getConnection();


            PreparedStatement ps =
            conn.prepareStatement(sql);



            ResultSet rs =
            ps.executeQuery();



            while(rs.next()){


                Equipment e =
                new Equipment();


                e.setEquipmentID(
                    rs.getInt("EquipmentID")
                );


                e.setEquipmentName(
                    rs.getString("EquipmentName")
                );


                e.setEquipmentType(
                    rs.getString("EquipmentType")
                );


                e.setConditionStatus(
                    rs.getString("ConditionStatus")
                );


                e.setPricePerDay(
                    rs.getDouble("PricePerDay")
                );


                e.setAvailabilityStatus(
                    rs.getBoolean("AvailabilityStatus")
                );


                e.setImagePath(
                    rs.getString("ImagePath")
                );


                list.add(e);


            }



            rs.close();
            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return list;


    }





    // ============================
    // GET EQUIPMENT BY ID
    // ============================
    public Equipment getEquipmentByID(int id){


        Equipment equipment = null;



        String sql =
        "SELECT * FROM Equipment WHERE EquipmentID=?";



        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setInt(1,id);



            ResultSet rs =
            ps.executeQuery();



            if(rs.next()){


                equipment =
                new Equipment();



                equipment.setEquipmentID(
                    rs.getInt("EquipmentID")
                );


                equipment.setEquipmentName(
                    rs.getString("EquipmentName")
                );


                equipment.setEquipmentType(
                    rs.getString("EquipmentType")
                );


                equipment.setConditionStatus(
                    rs.getString("ConditionStatus")
                );


                equipment.setPricePerDay(
                    rs.getDouble("PricePerDay")
                );


                equipment.setAvailabilityStatus(
                    rs.getBoolean("AvailabilityStatus")
                );


                equipment.setImagePath(
                    rs.getString("ImagePath")
                );


            }



            rs.close();
            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return equipment;


    }





    // ============================
    // SEARCH EQUIPMENT
    // ============================
    public ArrayList<Equipment> searchEquipment(String keyword){


        ArrayList<Equipment> list =
        new ArrayList<>();



        String sql =
        "SELECT * FROM Equipment " +
        "WHERE EquipmentName LIKE ? " +
        "OR EquipmentType LIKE ?";



        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setString(1,
                "%" + keyword + "%"
            );


            ps.setString(2,
                "%" + keyword + "%"
            );



            ResultSet rs =
            ps.executeQuery();



            while(rs.next()){


                Equipment e =
                new Equipment();


                e.setEquipmentID(
                    rs.getInt("EquipmentID")
                );


                e.setEquipmentName(
                    rs.getString("EquipmentName")
                );


                e.setEquipmentType(
                    rs.getString("EquipmentType")
                );


                e.setConditionStatus(
                    rs.getString("ConditionStatus")
                );


                e.setPricePerDay(
                    rs.getDouble("PricePerDay")
                );


                e.setAvailabilityStatus(
                    rs.getBoolean("AvailabilityStatus")
                );


                e.setImagePath(
                    rs.getString("ImagePath")
                );


                list.add(e);


            }



            rs.close();
            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return list;


    }





    // ============================
    // ADD EQUIPMENT
    // ============================
    public boolean addEquipment(Equipment e){


        boolean success = false;



        String sql =
        "INSERT INTO Equipment " +
        "(EquipmentName, EquipmentType, ConditionStatus, PricePerDay, AvailabilityStatus, ImagePath) " +
        "VALUES(?,?,?,?,?,?)";



        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setString(1,
                e.getEquipmentName()
            );


            ps.setString(2,
                e.getEquipmentType()
            );


            ps.setString(3,
                e.getConditionStatus()
            );


            ps.setDouble(4,
                e.getPricePerDay()
            );


            ps.setBoolean(5,
                e.isAvailabilityStatus()
            );


            ps.setString(6,
                e.getImagePath()
            );



            success =
            ps.executeUpdate() > 0;



            ps.close();
            conn.close();



        }catch(Exception ex){

            ex.printStackTrace();

        }



        return success;


    }





    // ============================
    // UPDATE EQUIPMENT
    // ============================
    public boolean updateEquipment(Equipment e){


        boolean success = false;



        String sql =
        "UPDATE Equipment SET " +
        "EquipmentName=?, " +
        "EquipmentType=?, " +
        "ConditionStatus=?, " +
        "PricePerDay=?, " +
        "AvailabilityStatus=?, " +
        "ImagePath=? " +
        "WHERE EquipmentID=?";



        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setString(1,
                e.getEquipmentName()
            );


            ps.setString(2,
                e.getEquipmentType()
            );


            ps.setString(3,
                e.getConditionStatus()
            );


            ps.setDouble(4,
                e.getPricePerDay()
            );


            ps.setBoolean(5,
                e.isAvailabilityStatus()
            );


            ps.setString(6,
                e.getImagePath()
            );


            ps.setInt(7,
                e.getEquipmentID()
            );



            success =
            ps.executeUpdate() > 0;



            ps.close();
            conn.close();



        }catch(Exception ex){

            ex.printStackTrace();

        }



        return success;


    }





    // ============================
    // UPDATE AVAILABILITY
    // ============================
    public boolean updateAvailability(int equipmentID,
                                      boolean available){


        boolean success = false;



        String sql =
        "UPDATE Equipment SET AvailabilityStatus=? WHERE EquipmentID=?";



        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setBoolean(1,
                available
            );


            ps.setInt(2,
                equipmentID
            );



            success =
            ps.executeUpdate() > 0;



            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return success;


    }





    // ============================
    // DELETE EQUIPMENT
    // ============================
    public boolean deleteEquipment(int id){


        boolean success = false;



        String sql =
        "DELETE FROM Equipment WHERE EquipmentID=?";



        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setInt(1,id);



            success =
            ps.executeUpdate() > 0;



            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return success;


    }





    // ============================
    // COUNT EQUIPMENT
    // ============================
    public int getEquipmentCount(){


        int count = 0;



        String sql =
        "SELECT COUNT(*) FROM Equipment";



        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ResultSet rs =
            ps.executeQuery();



            if(rs.next()){

                count =
                rs.getInt(1);

            }



            rs.close();
            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return count;


    }



}