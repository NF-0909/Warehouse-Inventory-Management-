package dao;

import bean.Rental;
import bean.Equipment;
import util.DBConnection;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class RentalsDAO {



    // ============================
    // ADD RENTAL REQUEST
    // ============================
    public int addRental(int customerID,
                         int equipmentID,
                         double totalAmount){


        int rentalID = -1;



        String sql =
        "INSERT INTO Rentals " +
        "(CustomerID, EmployeeID, EquipmentID, StartDate, EndDate, Status, TotalAmount) " +
        "VALUES (?, NULL, ?, CURRENT_DATE, NULL, 'Pending', ?)";



        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps =
            conn.prepareStatement(
                sql,
                PreparedStatement.RETURN_GENERATED_KEYS
            );



            ps.setInt(1, customerID);

            ps.setInt(2, equipmentID);

            ps.setDouble(3, totalAmount);



            ps.executeUpdate();



            ResultSet rs =
            ps.getGeneratedKeys();



            if(rs.next()){


                rentalID =
                rs.getInt(1);


            }



            rs.close();
            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return rentalID;


    }

    // ============================
    // ADD RENTAL REQUEST WITH DATES (used by cart checkout)
    // ============================
    public int addRental(int customerID,
                         int equipmentID,
                         Date startDate,
                         Date endDate,
                         double totalAmount){

        int rentalID = -1;

        String sql =
        "INSERT INTO Rentals " +
        "(CustomerID, EmployeeID, EquipmentID, StartDate, EndDate, Status, TotalAmount) " +
        "VALUES (?, NULL, ?, ?, ?, 'Pending', ?)";

        try{

            Connection conn =
            DBConnection.getConnection();

            PreparedStatement ps =
            conn.prepareStatement(
                sql,
                PreparedStatement.RETURN_GENERATED_KEYS
            );

            ps.setInt(1, customerID);
            ps.setInt(2, equipmentID);
            ps.setDate(3, startDate);
            ps.setDate(4, endDate);
            ps.setDouble(5, totalAmount);

            ps.executeUpdate();

            ResultSet rs =
            ps.getGeneratedKeys();

            if(rs.next()){

                rentalID =
                rs.getInt(1);

            }

            rs.close();
            ps.close();
            conn.close();

        }catch(Exception e){

            e.printStackTrace();

        }

        return rentalID;

    }






    // ============================
    // GET CUSTOMER RENTALS
    // ============================
    public ArrayList<Rental> getRentalsByCustomer(int customerID){


        ArrayList<Rental> list =
        new ArrayList<>();



        String sql =
        "SELECT r.*, e.EquipmentName " +
        "FROM Rentals r " +
        "JOIN Equipment e " +
        "ON r.EquipmentID=e.EquipmentID " +
        "WHERE r.CustomerID=? " +
        "ORDER BY r.RentalID DESC";



        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setInt(1,customerID);



            ResultSet rs =
            ps.executeQuery();



            while(rs.next()){


                Rental rental =
                new Rental();



                rental.setRentalID(
                    rs.getInt("RentalID")
                );


                rental.setCustomerID(
                    rs.getInt("CustomerID")
                );


                rental.setEmployeeID(
                    rs.getInt("EmployeeID")
                );


                rental.setEquipmentID(
                    rs.getInt("EquipmentID")
                );


                rental.setEquipmentName(
                    rs.getString("EquipmentName")
                );


                rental.setStartDate(
                    rs.getDate("StartDate")
                );


                rental.setEndDate(
                    rs.getDate("EndDate")
                );


                rental.setStatus(
                    rs.getString("Status")
                );


                rental.setTotalAmount(
                    rs.getDouble("TotalAmount")
                );



                list.add(rental);


            }



            rs.close();
            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return list;


    }





    // ============================
    // GET PENDING RENTALS
    // EMPLOYEE APPROVAL PAGE
    // ============================
    public ArrayList<Rental> getPendingRentals(){


        ArrayList<Rental> list =
        new ArrayList<>();



        String sql =
        "SELECT r.*, c.UserName, e.EquipmentName " +
        "FROM Rentals r " +
        "JOIN Customer c ON r.CustomerID=c.CustomerID " +
        "JOIN Equipment e ON r.EquipmentID=e.EquipmentID " +
        "WHERE r.Status='Pending' " +
        "ORDER BY r.RentalID DESC";



        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ResultSet rs =
            ps.executeQuery();



            while(rs.next()){


                Rental rental =
                new Rental();



                rental.setRentalID(
                    rs.getInt("RentalID")
                );


                rental.setCustomerID(
                    rs.getInt("CustomerID")
                );


                rental.setEquipmentID(
                    rs.getInt("EquipmentID")
                );


                rental.setCustomerName(
                    rs.getString("UserName")
                );


                rental.setEquipmentName(
                    rs.getString("EquipmentName")
                );


                rental.setStartDate(
                    rs.getDate("StartDate")
                );


                rental.setStatus(
                    rs.getString("Status")
                );



                list.add(rental);


            }



            rs.close();
            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return list;


    }





    // ============================
    // APPROVE RENTAL
    // ============================
    public boolean approveRental(int rentalID,
                                 int employeeID){


        boolean success = false;



        try{


            Connection conn =
            DBConnection.getConnection();



            String sql =
            "UPDATE Rentals " +
            "SET EmployeeID=?, Status='Active' " +
            "WHERE RentalID=?";



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setInt(1,employeeID);

            ps.setInt(2,rentalID);



            success =
            ps.executeUpdate()>0;



            ps.close();
            conn.close();




            if(success){


                int equipmentID =
                getEquipmentID(rentalID);



                EquipmentDAO dao =
                new EquipmentDAO();



                dao.updateAvailability(
                    equipmentID,
                    false
                );


            }



        }catch(Exception e){

            e.printStackTrace();

        }



        return success;


    }





    // ============================
    // RETURN RENTAL
    // ============================
    public boolean returnRental(int rentalID){


        boolean success = false;



        String sql =
        "UPDATE Rentals " +
        "SET Status='Completed', EndDate=CURRENT_DATE " +
        "WHERE RentalID=?";



        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setInt(1,rentalID);



            success =
            ps.executeUpdate()>0;



            ps.close();
            conn.close();



            if(success){


                int equipmentID =
                getEquipmentID(rentalID);



                EquipmentDAO equipmentDAO =
                new EquipmentDAO();



                equipmentDAO.updateAvailability(
                    equipmentID,
                    true
                );


            }



        }catch(Exception e){

            e.printStackTrace();

        }



        return success;


    }





    // ============================
    // GET EQUIPMENT ID FROM RENTAL
    // ============================
    public int getEquipmentID(int rentalID){


        int equipmentID = -1;



        String sql =
        "SELECT EquipmentID FROM Rentals WHERE RentalID=?";



        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setInt(1,rentalID);



            ResultSet rs =
            ps.executeQuery();



            if(rs.next()){


                equipmentID =
                rs.getInt("EquipmentID");


            }



            rs.close();
            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return equipmentID;


    }





    // ============================
    // GET RENTAL BY ID
    // ============================
    public Rental getRentalByID(int rentalID){


        Rental rental = null;



        String sql =
        "SELECT * FROM Rentals WHERE RentalID=?";



        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setInt(1,rentalID);



            ResultSet rs =
            ps.executeQuery();



            if(rs.next()){


                rental =
                new Rental();



                rental.setRentalID(
                    rs.getInt("RentalID")
                );


                rental.setCustomerID(
                    rs.getInt("CustomerID")
                );


                rental.setEmployeeID(
                    rs.getInt("EmployeeID")
                );


                rental.setEquipmentID(
                    rs.getInt("EquipmentID")
                );


                rental.setStartDate(
                    rs.getDate("StartDate")
                );


                rental.setEndDate(
                    rs.getDate("EndDate")
                );


                rental.setStatus(
                    rs.getString("Status")
                );


                rental.setTotalAmount(
                    rs.getDouble("TotalAmount")
                );


            }



            rs.close();
            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return rental;


    }





    // ============================
    // DASHBOARD COUNTS
    // ============================
    public int getActiveRentalCount(){


        return getCountByStatus("Active");


    }



    public int getPendingRentalCount(){


        return getCountByStatus("Pending");


    }





    private int getCountByStatus(String status){


        int count = 0;



        String sql =
        "SELECT COUNT(*) FROM Rentals WHERE Status=?";



        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setString(1,status);



            ResultSet rs =
            ps.executeQuery();



            if(rs.next()){


                count =
                rs.getInt(1);


            }



            rs.close();
            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return count;


    }


    // ============================
    // MOST RENTED EQUIPMENT
    // (used by customer dashboard "Most Rented Equipment" card)
    // ============================
    public static class PopularEquipment {

        private Equipment equipment;
        private int rentalCount;

        public Equipment getEquipment(){
            return equipment;
        }

        public void setEquipment(Equipment equipment){
            this.equipment = equipment;
        }

        public int getRentalCount(){
            return rentalCount;
        }

        public void setRentalCount(int rentalCount){
            this.rentalCount = rentalCount;
        }
    }

    public PopularEquipment getMostRentedEquipment(){

        PopularEquipment result = null;

        String sql =
        "SELECT e.EquipmentID, e.EquipmentName, e.EquipmentType, " +
        "e.ConditionStatus, e.PricePerDay, e.AvailabilityStatus, e.ImagePath, " +
        "COUNT(r.RentalID) AS RentalCount " +
        "FROM Rentals r " +
        "JOIN Equipment e ON r.EquipmentID = e.EquipmentID " +
        "GROUP BY e.EquipmentID, e.EquipmentName, e.EquipmentType, " +
        "e.ConditionStatus, e.PricePerDay, e.AvailabilityStatus, e.ImagePath " +
        "ORDER BY RentalCount DESC " +
        "FETCH FIRST 1 ROWS ONLY";

        try{

            Connection conn =
            DBConnection.getConnection();

            PreparedStatement ps =
            conn.prepareStatement(sql);

            ResultSet rs =
            ps.executeQuery();

            if(rs.next()){

                Equipment equipment =
                new Equipment();

                equipment.setEquipmentID(
                    rs.getInt("EquipmentID")
                );

                equipment.setEquipmentName(
                    rs.getString("EquipmentName")
                );

                equipment.setEquipmentType(
                    rs.getString("EquipmentType")
                );

                equipment.setConditionStatus(
                    rs.getString("ConditionStatus")
                );

                equipment.setPricePerDay(
                    rs.getDouble("PricePerDay")
                );

                equipment.setAvailabilityStatus(
                    rs.getBoolean("AvailabilityStatus")
                );

                equipment.setImagePath(
                    rs.getString("ImagePath")
                );

                result =
                new PopularEquipment();

                result.setEquipment(equipment);
                result.setRentalCount(rs.getInt("RentalCount"));

            }

            rs.close();
            ps.close();
            conn.close();

        }catch(Exception e){

            e.printStackTrace();

        }

        return result;

    }



}