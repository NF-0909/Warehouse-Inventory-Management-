package dao;

import bean.Customer;
import util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CustomerDAO {


    // ============================
    // REGISTER CUSTOMER
    // ============================
    public boolean register(Customer customer) {

        boolean status = false;

        String sql =
        "INSERT INTO Customer(UserName, Email, Password, Role) VALUES (?, ?, ?, ?)";

        try {

            Connection conn = DBConnection.getConnection();

            PreparedStatement ps =
            conn.prepareStatement(sql);


            ps.setString(1, customer.getUserName());
            ps.setString(2, customer.getEmail());
            ps.setString(3, customer.getPassword());
            ps.setString(4, "CUSTOMER");


            int result =
            ps.executeUpdate();


            if(result > 0){

                status = true;

            }


            ps.close();
            conn.close();


        }catch(Exception e){

            e.printStackTrace();

        }


        return status;

    }



    // ============================
    // CUSTOMER LOGIN
    // ============================
    public Customer login(String email, String password){

        Customer customer = null;


        String sql =
        "SELECT * FROM Customer WHERE Email=? AND Password=?";


        try{


            Connection conn =
            DBConnection.getConnection();


            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setString(1,email);
            ps.setString(2,password);



            ResultSet rs =
            ps.executeQuery();



            if(rs.next()){


                customer = new Customer();


                customer.setCustomerID(
                    rs.getInt("CustomerID")
                );


                customer.setUserName(
                    rs.getString("UserName")
                );


                customer.setEmail(
                    rs.getString("Email")
                );


                customer.setPassword(
                    rs.getString("Password")
                );


                customer.setRole(
                    rs.getString("Role")
                );


            }



            rs.close();
            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }


        return customer;

    }





    // ============================
    // GET TOTAL CUSTOMER COUNT
    // ============================
    public int getCustomerCount(){


        int count = 0;


        String sql =
        "SELECT COUNT(*) FROM Customer";


        try{


            Connection conn =
            DBConnection.getConnection();


            PreparedStatement ps =
            conn.prepareStatement(sql);


            ResultSet rs =
            ps.executeQuery();



            if(rs.next()){


                count =
                rs.getInt(1);


            }



            rs.close();
            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }


        return count;

    }





    // ============================
    // GET CUSTOMER BY ID
    // ============================
    public Customer getCustomerByID(int id){


        Customer customer = null;


        String sql =
        "SELECT * FROM Customer WHERE CustomerID=?";



        try{


            Connection conn =
            DBConnection.getConnection();


            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setInt(1,id);



            ResultSet rs =
            ps.executeQuery();



            if(rs.next()){


                customer = new Customer();


                customer.setCustomerID(
                    rs.getInt("CustomerID")
                );


                customer.setUserName(
                    rs.getString("UserName")
                );


                customer.setEmail(
                    rs.getString("Email")
                );


                customer.setPassword(
                    rs.getString("Password")
                );


                customer.setRole(
                    rs.getString("Role")
                );


            }



            rs.close();
            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }


        return customer;

    }





    // ============================
    // UPDATE CUSTOMER PROFILE
    // ============================
    public boolean updateProfile(Customer customer){


        boolean success = false;


        try{


            Connection conn =
            DBConnection.getConnection();


            PreparedStatement ps;



            if(customer.getPassword()==null ||
               customer.getPassword().trim().equals("")){


                String sql =
                "UPDATE Customer SET UserName=?, Email=? WHERE CustomerID=?";


                ps =
                conn.prepareStatement(sql);



                ps.setString(1,
                    customer.getUserName()
                );


                ps.setString(2,
                    customer.getEmail()
                );


                ps.setInt(3,
                    customer.getCustomerID()
                );


            }
            else{


                String sql =
                "UPDATE Customer SET UserName=?, Email=?, Password=? WHERE CustomerID=?";


                ps =
                conn.prepareStatement(sql);



                ps.setString(1,
                    customer.getUserName()
                );


                ps.setString(2,
                    customer.getEmail()
                );


                ps.setString(3,
                    customer.getPassword()
                );


                ps.setInt(4,
                    customer.getCustomerID()
                );


            }



            success =
            ps.executeUpdate() > 0;



            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return success;


    }



}