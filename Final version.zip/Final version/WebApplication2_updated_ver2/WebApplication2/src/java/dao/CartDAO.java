package dao;


import bean.Cart;
import util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;



public class CartDAO {



    // =================================
    // ADD ITEM TO CART
    // =================================

    public boolean addCart(Cart cart){


        boolean success=false;


        try{


            Connection conn =
            DBConnection.getConnection();




            if(conn == null){
                System.out.println("CartDAO.addCart: DBConnection.getConnection() returned null.");
                return false;
            }

            String sql =
            "INSERT INTO Cart(CustomerID, EquipmentID, Quantity, StartDate, EndDate) VALUES(?,?,?,?,?)";



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setInt(1, cart.getCustomerID());

            ps.setInt(2, cart.getEquipmentID());

            ps.setInt(3, cart.getQuantity());

            ps.setDate(4, cart.getStartDate());

            ps.setDate(5, cart.getEndDate());



            success =
            ps.executeUpdate() > 0;



            conn.close();



        }catch(Exception e){

            System.out.println("CartDAO.addCart failed: " + e.getMessage());
            e.printStackTrace();

        }



        return success;

    }







    // =================================
    // GET CART BY CUSTOMER
    // =================================


    public ArrayList<Cart> getCartByCustomer(int customerID){



        ArrayList<Cart> list =
        new ArrayList<>();



        try{


            Connection conn =
            DBConnection.getConnection();



            String sql =
            "SELECT c.*, e.EquipmentName, e.PricePerDay " +
            "FROM Cart c " +
            "JOIN Equipment e " +
            "ON c.EquipmentID=e.EquipmentID " +
            "WHERE c.CustomerID=?";



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setInt(1, customerID);



            ResultSet rs =
            ps.executeQuery();




            while(rs.next()){



                Cart c =
                new Cart();



                c.setCartID(
                rs.getInt("CartID"));



                c.setCustomerID(
                rs.getInt("CustomerID"));



                c.setEquipmentID(
                rs.getInt("EquipmentID"));



                c.setQuantity(
                rs.getInt("Quantity"));



                c.setStartDate(
                rs.getDate("StartDate"));



                c.setEndDate(
                rs.getDate("EndDate"));



                c.setEquipmentName(
                rs.getString("EquipmentName"));



                c.setPricePerDay(
                rs.getDouble("PricePerDay"));



                list.add(c);



            }



            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return list;

    }







    // =================================
    // REMOVE SINGLE CART ITEM
    // =================================


    public boolean removeCart(int cartID){


        boolean success=false;



        try{


            Connection conn =
            DBConnection.getConnection();



            String sql =
            "DELETE FROM Cart WHERE CartID=?";



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setInt(1,cartID);



            success =
            ps.executeUpdate()>0;



            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return success;

    }








    // =================================
    // CLEAR CART AFTER CHECKOUT
    // =================================


    public boolean clearCart(int customerID){


        boolean success=false;



        try{


            Connection conn =
            DBConnection.getConnection();



            String sql =
            "DELETE FROM Cart WHERE CustomerID=?";



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setInt(1,customerID);



            success =
            ps.executeUpdate()>0;



            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return success;

    }








    // =================================
    // COUNT CART ITEM
    // =================================


    public int getCartCount(int customerID){



        int count=0;



        try{


            Connection conn =
            DBConnection.getConnection();



            String sql =
            "SELECT COUNT(*) FROM Cart WHERE CustomerID=?";



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setInt(1,customerID);



            ResultSet rs =
            ps.executeQuery();



            if(rs.next()){

                count =
                rs.getInt(1);

            }



            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return count;


    }




}