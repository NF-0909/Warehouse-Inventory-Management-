package dao;


import bean.Maintenance;
import util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.ArrayList;



public class MaintenanceDAO {



    // Get all maintenance records

    public ArrayList<Maintenance> getAllMaintenance() {


        ArrayList<Maintenance> list =
                new ArrayList<>();


        try {


            Connection conn =
                    DBConnection.getConnection();



            String sql =
                    "SELECT m.*, e.EquipmentName " +
                    "FROM Maintenance m " +
                    "JOIN Equipment e " +
                    "ON m.EquipmentID = e.EquipmentID";



            PreparedStatement ps =
                    conn.prepareStatement(sql);



            ResultSet rs =
                    ps.executeQuery();



            while (rs.next()) {


                Maintenance m =
                        new Maintenance();



                m.setMaintenanceID(
                        rs.getInt("MaintenanceID")
                );


                m.setEmployeeID(
                        rs.getInt("EmployeeID")
                );


                m.setEquipmentID(
                        rs.getInt("EquipmentID")
                );


                m.setEquipmentName(
                        rs.getString("EquipmentName")
                );


                m.setIssue(
                        rs.getString("Issue")
                );


                m.setRepairDate(
                        rs.getDate("RepairDate")
                );


                m.setStatus(
                        rs.getString("Status")
                );



                list.add(m);


            }



            conn.close();



        } catch (Exception e) {


            e.printStackTrace();


        }



        return list;


    }





    // Get active maintenance only

    public ArrayList<Maintenance> getActiveMaintenance() {


        ArrayList<Maintenance> list =
                new ArrayList<>();



        try {


            Connection conn =
                    DBConnection.getConnection();



            String sql =
                    "SELECT m.*, e.EquipmentName " +
                    "FROM Maintenance m " +
                    "JOIN Equipment e " +
                    "ON m.EquipmentID = e.EquipmentID " +
                    "WHERE m.Status <> 'Completed'";



            PreparedStatement ps =
                    conn.prepareStatement(sql);



            ResultSet rs =
                    ps.executeQuery();



            while (rs.next()) {


                Maintenance m =
                        new Maintenance();



                m.setMaintenanceID(
                        rs.getInt("MaintenanceID")
                );


                m.setEmployeeID(
                        rs.getInt("EmployeeID")
                );


                m.setEquipmentID(
                        rs.getInt("EquipmentID")
                );


                m.setEquipmentName(
                        rs.getString("EquipmentName")
                );


                m.setIssue(
                        rs.getString("Issue")
                );


                m.setRepairDate(
                        rs.getDate("RepairDate")
                );


                m.setStatus(
                        rs.getString("Status")
                );



                list.add(m);


            }



            conn.close();



        } catch(Exception e) {


            e.printStackTrace();


        }



        return list;


    }





    // Get maintenance by ID

    public Maintenance getMaintenanceByID(int id) {


        Maintenance m = null;



        try {


            Connection conn =
                    DBConnection.getConnection();



            String sql =
                    "SELECT * FROM Maintenance " +
                    "WHERE MaintenanceID=?";



            PreparedStatement ps =
                    conn.prepareStatement(sql);



            ps.setInt(1, id);



            ResultSet rs =
                    ps.executeQuery();



            if(rs.next()) {



                m = new Maintenance();



                m.setMaintenanceID(
                        rs.getInt("MaintenanceID")
                );


                m.setEmployeeID(
                        rs.getInt("EmployeeID")
                );


                m.setEquipmentID(
                        rs.getInt("EquipmentID")
                );


                m.setIssue(
                        rs.getString("Issue")
                );


                m.setRepairDate(
                        rs.getDate("RepairDate")
                );


                m.setStatus(
                        rs.getString("Status")
                );



            }



            conn.close();



        } catch(Exception e) {


            e.printStackTrace();


        }



        return m;


    }





    // Update maintenance

    public boolean updateMaintenance(
            int id,
            String status,
            String issue) {


        boolean success = false;



        try {


            Connection conn =
                    DBConnection.getConnection();



            String sql =
                    "UPDATE Maintenance " +
                    "SET Issue=?, Status=?, RepairDate=CURRENT_DATE " +
                    "WHERE MaintenanceID=?";



            PreparedStatement ps =
                    conn.prepareStatement(sql);



            ps.setString(1, issue);

            ps.setString(2, status);

            ps.setInt(3, id);



            success =
                    ps.executeUpdate() > 0;



            conn.close();



        } catch(Exception e) {


            e.printStackTrace();


        }



        return success;


    }





    // Get completed maintenance history

    public ArrayList<Maintenance> getCompletedMaintenance() {


        ArrayList<Maintenance> list =
                new ArrayList<>();



        try {


            Connection conn =
                    DBConnection.getConnection();



            String sql =
                    "SELECT m.*, e.EquipmentName " +
                    "FROM Maintenance m " +
                    "JOIN Equipment e " +
                    "ON m.EquipmentID=e.EquipmentID " +
                    "WHERE m.Status='Completed'";



            PreparedStatement ps =
                    conn.prepareStatement(sql);



            ResultSet rs =
                    ps.executeQuery();



            while(rs.next()) {


                Maintenance m =
                        new Maintenance();



                m.setMaintenanceID(
                        rs.getInt("MaintenanceID")
                );


                m.setEmployeeID(
                        rs.getInt("EmployeeID")
                );


                m.setEquipmentID(
                        rs.getInt("EquipmentID")
                );


                m.setEquipmentName(
                        rs.getString("EquipmentName")
                );


                m.setIssue(
                        rs.getString("Issue")
                );


                m.setRepairDate(
                        rs.getDate("RepairDate")
                );


                m.setStatus(
                        rs.getString("Status")
                );



                list.add(m);


            }



            conn.close();



        } catch(Exception e) {


            e.printStackTrace();


        }



        return list;


    }





    // Count maintenance by status

    public int getMaintenanceCount(String status) {


        int count = 0;



        try {


            Connection conn =
                    DBConnection.getConnection();



            String sql =
                    "SELECT COUNT(*) " +
                    "FROM Maintenance " +
                    "WHERE Status=?";



            PreparedStatement ps =
                    conn.prepareStatement(sql);



            ps.setString(1, status);



            ResultSet rs =
                    ps.executeQuery();



            if(rs.next()) {


                count =
                    rs.getInt(1);


            }



            conn.close();



        } catch(Exception e) {


            e.printStackTrace();


        }



        return count;


    }





    // Add maintenance

    public boolean addMaintenance(Maintenance m) {


        boolean success = false;



        try {


            Connection conn =
                    DBConnection.getConnection();



            String sql =
                    "INSERT INTO Maintenance" +
                    "(EmployeeID, EquipmentID, Issue, RepairDate, Status) " +
                    "VALUES(?,?,?,CURRENT_DATE,?)";



            PreparedStatement ps =
                    conn.prepareStatement(sql);



            ps.setInt(1, m.getEmployeeID());

            ps.setInt(2, m.getEquipmentID());

            ps.setString(3, m.getIssue());

            ps.setString(4, m.getStatus());



            success =
                    ps.executeUpdate() > 0;



            conn.close();



        } catch(Exception e) {


            e.printStackTrace();


        }



        return success;


    }





    // Delete maintenance

    public boolean deleteMaintenance(int maintenanceID) {


        boolean success = false;



        try {


            Connection conn =
                    DBConnection.getConnection();



            String sql =
                    "DELETE FROM Maintenance " +
                    "WHERE MaintenanceID=?";



            PreparedStatement ps =
                    conn.prepareStatement(sql);



            ps.setInt(1, maintenanceID);



            success =
                    ps.executeUpdate() > 0;



            conn.close();



        } catch(Exception e) {


            e.printStackTrace();


        }



        return success;


    }



}