package dao;

import bean.Employee;
import util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class EmployeeDAO {


    // ============================
    // EMPLOYEE LOGIN
    // ============================
    public Employee login(String email, String password){


        Employee employee = null;


        String sql =
        "SELECT * FROM Employee WHERE Email=? AND Password=?";


        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setString(1,email);

            ps.setString(2,password);



            ResultSet rs =
            ps.executeQuery();



            if(rs.next()){


                employee = new Employee();



                employee.setEmployeeID(
                    rs.getInt("EmployeeID")
                );


                employee.setEmployeeName(
                    rs.getString("EmployeeName")
                );


                employee.setEmail(
                    rs.getString("Email")
                );


                employee.setPassword(
                    rs.getString("Password")
                );


                employee.setPosition(
                    rs.getString("Position")
                );


                employee.setSupervisorID(
                    rs.getInt("SupervisorID")
                );


                employee.setRole(
                    rs.getString("Role")
                );


            }



            rs.close();
            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return employee;


    }




    // ============================
    // GET EMPLOYEE BY ID
    // ============================
    public Employee getEmployeeByID(int id){


        Employee employee = null;



        String sql =
        "SELECT * FROM Employee WHERE EmployeeID=?";



        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ps.setInt(1,id);



            ResultSet rs =
            ps.executeQuery();




            if(rs.next()){


                employee = new Employee();



                employee.setEmployeeID(
                    rs.getInt("EmployeeID")
                );


                employee.setEmployeeName(
                    rs.getString("EmployeeName")
                );


                employee.setEmail(
                    rs.getString("Email")
                );


                employee.setPassword(
                    rs.getString("Password")
                );


                employee.setPosition(
                    rs.getString("Position")
                );


                employee.setSupervisorID(
                    rs.getInt("SupervisorID")
                );


                employee.setRole(
                    rs.getString("Role")
                );


            }



            rs.close();
            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return employee;


    }





    // ============================
    // UPDATE EMPLOYEE PROFILE
    // ============================
    public boolean updateProfile(Employee employee){


        boolean success = false;



        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps;



            if(employee.getPassword()==null ||
               employee.getPassword().trim().equals("")){


                String sql =
                "UPDATE Employee SET EmployeeName=?, Email=? WHERE EmployeeID=?";



                ps =
                conn.prepareStatement(sql);



                ps.setString(1,
                    employee.getEmployeeName()
                );


                ps.setString(2,
                    employee.getEmail()
                );


                ps.setInt(3,
                    employee.getEmployeeID()
                );


            }
            else{


                String sql =
                "UPDATE Employee SET EmployeeName=?, Email=?, Password=? WHERE EmployeeID=?";



                ps =
                conn.prepareStatement(sql);



                ps.setString(1,
                    employee.getEmployeeName()
                );


                ps.setString(2,
                    employee.getEmail()
                );


                ps.setString(3,
                    employee.getPassword()
                );


                ps.setInt(4,
                    employee.getEmployeeID()
                );


            }



            success =
            ps.executeUpdate() > 0;



            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return success;


    }





    // ============================
    // GET EMPLOYEE COUNT
    // ============================
    public int getEmployeeCount(){


        int count = 0;



        String sql =
        "SELECT COUNT(*) FROM Employee";



        try{


            Connection conn =
            DBConnection.getConnection();



            PreparedStatement ps =
            conn.prepareStatement(sql);



            ResultSet rs =
            ps.executeQuery();



            if(rs.next()){


                count =
                rs.getInt(1);


            }



            rs.close();
            ps.close();
            conn.close();



        }catch(Exception e){

            e.printStackTrace();

        }



        return count;


    }



}