package bean;

import java.sql.Date;

public class Rental {

    private int rentalID;
    private int customerID;
    private int employeeID;
    private int equipmentID;

    private Date startDate;
    private Date endDate;

    private String status;

    private double totalAmount;

    private String equipmentName;
    private String customerName;

    public Rental() {

    }

    public Rental(int rentalID,
                  int customerID,
                  int employeeID,
                  int equipmentID,
                  Date startDate,
                  Date endDate,
                  String status,
                  double totalAmount,
                  String equipmentName,
                  String customerName){

        this.rentalID = rentalID;
        this.customerID = customerID;
        this.employeeID = employeeID;
        this.equipmentID = equipmentID;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
        this.totalAmount = totalAmount;
        this.equipmentName = equipmentName;
        this.customerName = customerName;

    }

    public int getRentalID() {
        return rentalID;
    }

    public void setRentalID(int rentalID) {
        this.rentalID = rentalID;
    }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public int getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(int employeeID) {
        this.employeeID = employeeID;
    }

    public int getEquipmentID() {
        return equipmentID;
    }

    public void setEquipmentID(int equipmentID) {
        this.equipmentID = equipmentID;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getEquipmentName() {
        return equipmentName;
    }

    public void setEquipmentName(String equipmentName) {
        this.equipmentName = equipmentName;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

}