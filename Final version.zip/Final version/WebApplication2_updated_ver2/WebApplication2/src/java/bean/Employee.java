package bean;

public class Employee {

    private int employeeID;
    private String employeeName;
    private String email;
    private String password;
    private String position;
    private int supervisorID;
    private String role;

    public Employee() {

    }

    public Employee(int employeeID,
                    String employeeName,
                    String email,
                    String password,
                    String position,
                    int supervisorID,
                    String role) {

        this.employeeID = employeeID;
        this.employeeName = employeeName;
        this.email = email;
        this.password = password;
        this.position = position;
        this.supervisorID = supervisorID;
        this.role = role;

    }

    public int getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(int employeeID) {
        this.employeeID = employeeID;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public int getSupervisorID() {
        return supervisorID;
    }

    public void setSupervisorID(int supervisorID) {
        this.supervisorID = supervisorID;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

}