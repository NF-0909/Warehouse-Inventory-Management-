package bean;

import java.sql.Date;


public class Cart {


    private int cartID;

    private int customerID;

    private int equipmentID;

    private int quantity;

    private Date startDate;

    private Date endDate;


    private String equipmentName;

    private double pricePerDay;



    public Cart(){

    }



    public int getCartID(){

        return cartID;

    }


    public void setCartID(int cartID){

        this.cartID = cartID;

    }



    public int getCustomerID(){

        return customerID;

    }


    public void setCustomerID(int customerID){

        this.customerID = customerID;

    }



    public int getEquipmentID(){

        return equipmentID;

    }


    public void setEquipmentID(int equipmentID){

        this.equipmentID = equipmentID;

    }



    public int getQuantity(){

        return quantity;

    }


    public void setQuantity(int quantity){

        this.quantity = quantity;

    }



    public Date getStartDate(){

        return startDate;

    }


    public void setStartDate(Date startDate){

        this.startDate = startDate;

    }



    public Date getEndDate(){

        return endDate;

    }


    public void setEndDate(Date endDate){

        this.endDate = endDate;

    }



    public String getEquipmentName(){

        return equipmentName;

    }


    public void setEquipmentName(String equipmentName){

        this.equipmentName = equipmentName;

    }



    public double getPricePerDay(){

        return pricePerDay;

    }


    public void setPricePerDay(double pricePerDay){

        this.pricePerDay = pricePerDay;

    }


}