package bean;

public class Customer {

    private int customerID;
    private String userName;
    private String email;
    private String password;
    private String role;

    public Customer() {
    }

    public Customer(int customerID, String userName, String email,
            String password, String role) {

        this.customerID = customerID;
        this.userName = userName;
        this.email = email;
        this.password = password;
        this.role = role;
    }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

}
