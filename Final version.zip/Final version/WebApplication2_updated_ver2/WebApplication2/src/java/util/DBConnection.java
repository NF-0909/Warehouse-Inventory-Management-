package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private static final String URL =
            "jdbc:derby://localhost:1527/EquipmentRentalDB";

    private static final String USER = "app";
    private static final String PASSWORD = "app";

    public static Connection getConnection() {

        Connection con = null;

        try {

            Class.forName("org.apache.derby.jdbc.ClientDriver");

            con = DriverManager.getConnection(URL, USER, PASSWORD);

            System.out.println("Database Connected");

        } catch (ClassNotFoundException | SQLException e) {

            System.out.println(e);

        }

        return con;

    }

}
