package util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;


public class ImageUploadUtil {

    
    private static final String UPLOAD_SUBFOLDER = "image/uploads";

    public static String saveUploadedImage(HttpServletRequest request,
                                            String partName,
                                            ServletContext context) {

        try {

            Part filePart = request.getPart(partName);

            if (filePart == null || filePart.getSize() <= 0) {
                return null;
            }

            String submittedFileName = getSubmittedFileName(filePart);

            if (submittedFileName == null || submittedFileName.trim().isEmpty()) {
                return null;
            }

            if (!isAllowedImage(submittedFileName)) {
                return null;
            }

            
            String realUploadDir = context.getRealPath("/" + UPLOAD_SUBFOLDER);

            if (realUploadDir == null) {
                
                String webRoot = context.getRealPath("/");

                if (webRoot == null) {
                    System.out.println(
                        "ImageUploadUtil: getRealPath() returned null for both "
                        + "'/" + UPLOAD_SUBFOLDER + "' and '/'. The app is likely "
                        + "deployed as a non-exploded .war archive. Enable "
                        + "'Automatically unpack WAR files' for this GlassFish/"
                        + "Payara domain, or deploy as an exploded directory, "
                        + "then redeploy."
                    );
                    return null;
                }

                realUploadDir = webRoot + UPLOAD_SUBFOLDER;
            }

            File uploadDir = new File(realUploadDir);

            if (!uploadDir.exists()) {
                boolean created = uploadDir.mkdirs();
                if (!created && !uploadDir.exists()) {
                    System.out.println(
                        "ImageUploadUtil: could not create upload directory at "
                        + uploadDir.getAbsolutePath()
                        + " (check folder permissions on the server)."
                    );
                    return null;
                }
            }

            
            String extension = getExtension(submittedFileName);
            String uniqueName = UUID.randomUUID().toString() + extension;

            File targetFile = new File(uploadDir, uniqueName);

            try (InputStream in = filePart.getInputStream();
                 OutputStream out = new FileOutputStream(targetFile)) {

                byte[] buffer = new byte[8192];
                int bytesRead;

                while ((bytesRead = in.read(buffer)) != -1) {
                    out.write(buffer, 0, bytesRead);
                }
            }

            
            return UPLOAD_SUBFOLDER + "/" + uniqueName;

        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    
    private static String getSubmittedFileName(Part part) {

        String fileName = part.getSubmittedFileName();

        if (fileName != null) {
            return fileName;
        }

        String header = part.getHeader("content-disposition");

        if (header != null) {
            for (String token : header.split(";")) {
                token = token.trim();
                if (token.startsWith("filename")) {
                    return token.substring(token.indexOf('=') + 1)
                            .trim().replace("\"", "");
                }
            }
        }

        return null;
    }

    private static String getExtension(String fileName) {

        int dotIndex = fileName.lastIndexOf('.');

        if (dotIndex == -1 || dotIndex == fileName.length() - 1) {
            return "";
        }

        return fileName.substring(dotIndex).toLowerCase();
    }

    private static boolean isAllowedImage(String fileName) {

        String ext = getExtension(fileName);

        return ext.equals(".jpg") || ext.equals(".jpeg")
                || ext.equals(".png") || ext.equals(".gif")
                || ext.equals(".webp") || ext.equals(".avif");
    }
}
