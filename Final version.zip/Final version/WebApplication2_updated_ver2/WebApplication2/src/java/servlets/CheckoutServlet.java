package servlets;

import bean.Cart;
import bean.Customer;
import dao.CartDAO;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/CheckoutServlet")
public class CheckoutServlet extends HttpServlet{

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException{

        HttpSession session =
        request.getSession();

        Customer customer =
        (Customer) session.getAttribute("customer");

        if(customer == null){
            response.sendRedirect("login.jsp");
            return;
        }

        CartDAO dao = new CartDAO();
        ArrayList<Cart> cartItems =
        dao.getCartByCustomer(customer.getCustomerID());

        if(cartItems == null || cartItems.isEmpty()){
            response.sendRedirect("Cart.jsp");
            return;
        }

        double total = 0;

        for(Cart item : cartItems){
            long days =
            ((item.getEndDate().getTime() - item.getStartDate().getTime())
                / (1000 * 60 * 60 * 24)) + 1;
            if(days < 1){
                days = 1;
            }
            total += item.getPricePerDay() * item.getQuantity() * days;
        }

        session.setAttribute("totalAmount", total);

        response.sendRedirect("Payment.jsp");
    }
}
