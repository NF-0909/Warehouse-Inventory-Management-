package servlets;

import bean.Cart;
import bean.Customer;
import dao.CartDAO;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/AddToCartServlet")
public class AddToCartServlet extends HttpServlet{

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException{

        HttpSession session = request.getSession();

        Customer customer = (Customer) session.getAttribute("customer");

        if(customer == null){
            response.sendRedirect("login.jsp");
            return;
        }

        int equipmentID =
        Integer.parseInt(request.getParameter("equipmentID"));

        int quantity = 1;
        String qtyParam = request.getParameter("quantity");
        if(qtyParam != null && !qtyParam.trim().equals("")){
            quantity = Integer.parseInt(qtyParam);
        }
        if(quantity < 1){
            quantity = 1;
        }

        String startDateParam = request.getParameter("startDate");
        String endDateParam = request.getParameter("endDate");

        if(startDateParam == null || startDateParam.trim().equals("") ||
           endDateParam == null || endDateParam.trim().equals("")){
            request.getSession().setAttribute("cartError",
                "Please select a start and end date.");
            response.sendRedirect("EquipmentCatalog.jsp");
            return;
        }

        Date startDate = Date.valueOf(startDateParam);
        Date endDate = Date.valueOf(endDateParam);

        if(endDate.before(startDate)){
            request.getSession().setAttribute("cartError",
                "End date cannot be before start date.");
            response.sendRedirect("EquipmentCatalog.jsp");
            return;
        }

        Cart cart = new Cart();
        cart.setCustomerID(customer.getCustomerID());
        cart.setEquipmentID(equipmentID);
        cart.setQuantity(quantity);
        cart.setStartDate(startDate);
        cart.setEndDate(endDate);

        CartDAO dao = new CartDAO();
        boolean added = dao.addCart(cart);

        if(!added){
            request.getSession().setAttribute("cartError",
                "Could not add this item to your cart. Please check the server log for details.");
            response.sendRedirect("EquipmentCatalog.jsp");
            return;
        }

        response.sendRedirect("Cart.jsp");
    }
}
