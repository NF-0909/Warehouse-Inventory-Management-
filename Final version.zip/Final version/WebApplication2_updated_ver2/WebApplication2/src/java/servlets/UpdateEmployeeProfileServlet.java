package servlets;

import bean.Employee;
import dao.EmployeeDAO;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/UpdateEmployeeProfileServlet")
public class UpdateEmployeeProfileServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session =
        request.getSession();

        Employee employee =
        (Employee) session.getAttribute("employee");
        
        if(employee == null){
        response.sendRedirect("login.jsp");
        return;
        }

        String employeeName =
        request.getParameter("employeeName");

        String email =
        request.getParameter("email");

        String password =
        request.getParameter("password");

        employee.setEmployeeName(employeeName);
        employee.setEmail(email);

        if(password != null &&
           !password.trim().equals("")){

            employee.setPassword(password);

        }

        EmployeeDAO dao =
        new EmployeeDAO();

        boolean success =
        dao.updateProfile(employee);

        if(success){

            session.setAttribute("employee", employee);

            response.sendRedirect("EmployeeProfile.jsp?success=1");

        }else{

            response.sendRedirect("EmployeeProfile.jsp?error=1");

        }

    }

}