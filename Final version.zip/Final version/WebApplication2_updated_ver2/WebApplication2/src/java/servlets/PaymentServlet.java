package servlets;

import bean.Cart;
import bean.Customer;

import dao.CartDAO;
import dao.PaymentDAO;
import dao.RentalsDAO;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/PaymentServlet")
public class PaymentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session =
                request.getSession();

        Customer customer =
        (Customer) session.getAttribute("customer");

        if(customer == null){
            response.sendRedirect("login.jsp");
            return;
        }

        CartDAO cartDAO = new CartDAO();
        ArrayList<Cart> cartItems =
        cartDAO.getCartByCustomer(customer.getCustomerID());

        if(cartItems == null || cartItems.isEmpty()){
            response.sendRedirect("Cart.jsp");
            return;
        }

        String paymentMethod =
        request.getParameter("paymentMethod");

        RentalsDAO rentalsDAO =
        new RentalsDAO();

        PaymentDAO paymentDAO =
        new PaymentDAO();

        for(Cart item : cartItems){

            long days =
            ((item.getEndDate().getTime() - item.getStartDate().getTime())
                / (1000 * 60 * 60 * 24)) + 1;
            if(days < 1){
                days = 1;
            }

            double amount =
            item.getPricePerDay() * item.getQuantity() * days;

            int rentalID =
            rentalsDAO.addRental(
                    customer.getCustomerID(),
                    item.getEquipmentID(),
                    item.getStartDate(),
                    item.getEndDate(),
                    amount
            );

            paymentDAO.addPayment(
                    rentalID,
                    amount,
                    paymentMethod
            );
        }

        cartDAO.clearCart(customer.getCustomerID());

        session.removeAttribute("totalAmount");

        response.sendRedirect("RentingStatus.jsp");
    }
}
