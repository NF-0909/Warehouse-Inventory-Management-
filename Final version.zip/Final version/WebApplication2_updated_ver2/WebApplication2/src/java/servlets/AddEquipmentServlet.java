package servlets;

import bean.Employee;
import bean.Equipment;
import dao.EquipmentDAO;
import util.ImageUploadUtil;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/AddEquipmentServlet")
@MultipartConfig(
        maxFileSize = 5 * 1024 * 1024,       // 5 MB per file
        maxRequestSize = 10 * 1024 * 1024    // 10 MB per request
)
public class AddEquipmentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        Employee employee =
                (session == null) ? null : (Employee) session.getAttribute("employee");

        if(employee == null){
            response.sendRedirect("login.jsp");
            return;
        }

        Equipment equipment = new Equipment();

        equipment.setEquipmentName(request.getParameter("name"));
        equipment.setEquipmentType(request.getParameter("type"));
        equipment.setConditionStatus(request.getParameter("condition"));

        equipment.setPricePerDay(
                Double.parseDouble(request.getParameter("price"))
        );

        equipment.setAvailabilityStatus(
                Boolean.parseBoolean(request.getParameter("available"))
        );

        // Save the uploaded image file (if any) and store its relative
        // web path, e.g. "image/uploads/3f2c1a-racket.jpg"
        String savedImagePath = ImageUploadUtil.saveUploadedImage(
                request, "imageFile", getServletContext()
        );

        equipment.setImagePath(
                (savedImagePath == null) ? "" : savedImagePath
        );

        EquipmentDAO dao = new EquipmentDAO();

        if(dao.addEquipment(equipment)){

            response.sendRedirect("EquipmentList.jsp");

        }else{

            response.getWriter().println("Failed to add equipment.");

        }

    }
}
