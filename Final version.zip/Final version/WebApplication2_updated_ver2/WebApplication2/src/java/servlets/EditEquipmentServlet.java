package servlets;

import bean.Employee;
import bean.Equipment;
import dao.EquipmentDAO;
import util.ImageUploadUtil;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/EditEquipmentServlet")
@MultipartConfig(
        maxFileSize = 5 * 1024 * 1024,       // 5 MB per file
        maxRequestSize = 10 * 1024 * 1024    // 10 MB per request
)
public class EditEquipmentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        Employee employee =
                (session == null) ? null : (Employee) session.getAttribute("employee");

        if(employee == null){
            response.sendRedirect("login.jsp");
            return;
        }

        int equipmentID =
                Integer.parseInt(request.getParameter("equipmentID"));

        EquipmentDAO dao = new EquipmentDAO();

        // Load the existing record first so we can keep the current
        // image if the employee doesn't upload a new one.
        Equipment existing = dao.getEquipmentByID(equipmentID);

        Equipment equipment = new Equipment();
        equipment.setEquipmentID(equipmentID);
        equipment.setEquipmentName(request.getParameter("name"));
        equipment.setEquipmentType(request.getParameter("type"));
        equipment.setConditionStatus(request.getParameter("condition"));

        equipment.setPricePerDay(
                Double.parseDouble(request.getParameter("price"))
        );

        equipment.setAvailabilityStatus(
                Boolean.parseBoolean(request.getParameter("available"))
        );

        // If a new image file was uploaded, save it and use its path.
        // Otherwise, keep whatever image path was already on record.
        String savedImagePath = ImageUploadUtil.saveUploadedImage(
                request, "imageFile", getServletContext()
        );

        if(savedImagePath != null){
            equipment.setImagePath(savedImagePath);
        }else{
            equipment.setImagePath(
                    (existing == null) ? "" : existing.getImagePath()
            );
        }

        if(dao.updateEquipment(equipment)){

            response.sendRedirect("EquipmentList.jsp");

        }else{

            response.getWriter().println("Failed to update equipment.");

        }

    }
}
