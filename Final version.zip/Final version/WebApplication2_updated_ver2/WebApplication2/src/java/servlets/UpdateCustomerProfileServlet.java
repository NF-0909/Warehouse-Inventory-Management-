package servlets;

import bean.Customer;
import dao.CustomerDAO;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/UpdateCustomerProfileServlet")
public class UpdateCustomerProfileServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session =
        request.getSession();

        Customer customer =
        (Customer) session.getAttribute("customer");
        if(customer == null){

        response.sendRedirect("login.jsp");
        return;

        }

        String username =
        request.getParameter("username");

        String email =
        request.getParameter("email");

        String password =
        request.getParameter("password");

        customer.setUserName(username);
        customer.setEmail(email);

        if(password != null &&
           !password.trim().equals("")){

            customer.setPassword(password);

        }

        CustomerDAO dao =
        new CustomerDAO();

        boolean success = dao.updateProfile(customer);

        if(success){

    session.setAttribute("customer", customer);

    response.sendRedirect("CustomerProfile.jsp?success=1");

    }else{

        response.sendRedirect("CustomerProfile.jsp?error=1");
    }
    }
}