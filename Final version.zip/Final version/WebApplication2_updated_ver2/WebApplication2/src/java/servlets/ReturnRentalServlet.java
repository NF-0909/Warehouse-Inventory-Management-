package servlets;

import dao.RentalsDAO;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ReturnRentalServlet")
public class ReturnRentalServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        try {

            int rentalID =
                    Integer.parseInt(request.getParameter("rentalID"));

            RentalsDAO dao = new RentalsDAO();

            boolean success =
                    dao.returnRental(rentalID);


            if(success){

                response.sendRedirect("RentingStatus.jsp");

            }else{

                response.sendRedirect("RentingStatus.jsp?error=returnFailed");

            }


        } catch(Exception e){

            e.printStackTrace();

            response.sendRedirect("RentingStatus.jsp?error=systemError");

        }

    }

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

}
