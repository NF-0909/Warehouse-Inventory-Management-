package servlets;

import dao.CartDAO;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/RemoveFromCartServlet")
public class RemoveFromCartServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        int cartID = Integer.parseInt(request.getParameter("cartID"));

        CartDAO dao = new CartDAO();
        dao.removeCart(cartID);

        response.sendRedirect("Cart.jsp");
    }

    protected void doPost(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
