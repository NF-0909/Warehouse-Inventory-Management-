package servlets;


import bean.Customer;
import bean.Employee;

import dao.CustomerDAO;
import dao.EmployeeDAO;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;



@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {



    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {



        String email =
        request.getParameter("email");


        String password =
        request.getParameter("password");



        // ==========================
        // EMPTY CHECK
        // ==========================

        if(email == null || password == null ||
           email.trim().equals("") ||
           password.trim().equals("")){


            request.setAttribute(
            "error",
            "Please enter email and password"
            );


            request.getRequestDispatcher(
            "login.jsp")
            .forward(request,response);


            return;

        }





        // ==========================
        // REMOVE OLD SESSION
        // ==========================


        HttpSession oldSession =
        request.getSession(false);


        if(oldSession != null){

            oldSession.invalidate();

        }





        // ==========================
        // CUSTOMER LOGIN
        // ==========================


        CustomerDAO customerDAO =
        new CustomerDAO();



        Customer customer =
        customerDAO.login(email,password);



        if(customer != null){



            HttpSession session =
            request.getSession(true);



            session.setAttribute(
            "customer",
            customer);



            session.setAttribute(
            "role",
            "CUSTOMER");



            response.sendRedirect(
            "dashboard.jsp");



            return;


        }







        // ==========================
        // EMPLOYEE LOGIN
        // ==========================


        EmployeeDAO employeeDAO =
        new EmployeeDAO();



        Employee employee =
        employeeDAO.login(email,password);




        if(employee != null){



            HttpSession session =
            request.getSession(true);



            session.setAttribute(
            "employee",
            employee);



            session.setAttribute(
            "role",
            employee.getRole());



            response.sendRedirect(
            "employeeDashboard.jsp");



            return;


        }







        // ==========================
        // FAILED LOGIN
        // ==========================


        request.setAttribute(
        "error",
        "Invalid Email or Password");



        request.getRequestDispatcher(
        "login.jsp")
        .forward(request,response);



    }



}