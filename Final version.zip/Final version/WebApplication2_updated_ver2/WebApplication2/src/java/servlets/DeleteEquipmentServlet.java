package servlets;

import bean.Employee;
import dao.EquipmentDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "DeleteEquipmentServlet", urlPatterns = {"/DeleteEquipmentServlet"})
public class DeleteEquipmentServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException{

        HttpSession session = request.getSession(false);
        Employee employee =
                (session == null) ? null : (Employee) session.getAttribute("employee");

        if(employee == null){
            response.sendRedirect("login.jsp");
            return;
        }

        int id =
        Integer.parseInt(request.getParameter("id"));

        EquipmentDAO dao =
        new EquipmentDAO();

        dao.deleteEquipment(id);

        response.sendRedirect("EquipmentList.jsp");

    }

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException{
        doGet(request, response);
    }
}
