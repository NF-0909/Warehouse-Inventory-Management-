package servlets;


import dao.MaintenanceDAO;
import bean.Employee;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;



@WebServlet("/UpdateMaintenanceServlet")
public class UpdateMaintenanceServlet extends HttpServlet {



    @Override
    protected void doPost(HttpServletRequest request,
                         HttpServletResponse response)
                         throws ServletException, IOException {



        HttpSession session =
                request.getSession(false);




        if(session == null){


            response.sendRedirect("login.jsp");

            return;


        }





        Employee employee =
                (Employee) session.getAttribute("employee");





        if(employee == null){


            response.sendRedirect("login.jsp");

            return;


        }







        int maintenanceID =
                Integer.parseInt(
                        request.getParameter("maintenanceID")
                );




        String status =
                request.getParameter("status");




        String issue =
                request.getParameter("remarks");







        MaintenanceDAO dao =
                new MaintenanceDAO();





        boolean success =
                dao.updateMaintenance(
                        maintenanceID,
                        status,
                        issue
                );







        if(success){


            response.sendRedirect(
                    "maintenanceList.jsp"
            );


        }
        else{


            request.setAttribute(
                    "error",
                    "Failed to update maintenance."
            );


            request.getRequestDispatcher(
                    "maintenanceList.jsp"
            )
            .forward(request,response);



        }



    }


}