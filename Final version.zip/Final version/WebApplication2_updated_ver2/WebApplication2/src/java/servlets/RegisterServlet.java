package servlets;


import bean.Customer;
import dao.CustomerDAO;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;



@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {



    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {



        String username =
        request.getParameter("username");


        String email =
        request.getParameter("email");


        String password =
        request.getParameter("password");


        String confirmPassword =
        request.getParameter("confirmPassword");



        // ============================
        // PASSWORD CHECK
        // ============================

        if(password == null || confirmPassword == null ||
           !password.equals(confirmPassword)){


            request.setAttribute(
            "error",
            "Password does not match"
            );


            request.getRequestDispatcher(
            "register.jsp")
            .forward(request,response);


            return;

        }






        Customer customer =
        new Customer();



        customer.setUserName(username);

        customer.setEmail(email);

        customer.setPassword(password);

        customer.setRole("CUSTOMER");




        CustomerDAO dao =
        new CustomerDAO();




        boolean success =
        dao.register(customer);




        if(success){


            response.sendRedirect(
            "login.jsp");


        }else{


            request.setAttribute(
            "error",
            "Registration failed. Email may already exist."
            );


            request.getRequestDispatcher(
            "register.jsp")
            .forward(request,response);


        }


    }



}