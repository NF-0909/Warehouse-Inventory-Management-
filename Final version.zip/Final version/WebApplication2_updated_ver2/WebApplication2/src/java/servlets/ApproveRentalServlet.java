package servlets;


import dao.RentalsDAO;
import bean.Employee;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;



@WebServlet("/ApproveRentalServlet")
public class ApproveRentalServlet extends HttpServlet {



    @Override
    protected void doPost(HttpServletRequest request,
                         HttpServletResponse response)
                         throws ServletException, IOException {



        HttpSession session =
                request.getSession(false);



        if(session == null){


            response.sendRedirect("login.jsp");

            return;


        }




        Employee employee =
                (Employee) session.getAttribute("employee");




        if(employee == null){


            response.sendRedirect("login.jsp");

            return;


        }






        int rentalID =
                Integer.parseInt(
                        request.getParameter("rentalID")
                );






        RentalsDAO dao =
                new RentalsDAO();





        boolean success =
                dao.approveRental(
                        rentalID,
                        employee.getEmployeeID()
                );







        if(success){


            response.sendRedirect(
                    "pendingRentals.jsp"
            );


        }
        else{


            request.setAttribute(
                    "error",
                    "Failed to approve rental."
            );


            request.getRequestDispatcher(
                    "pendingRentals.jsp"
            )
            .forward(request,response);



        }



    }


}