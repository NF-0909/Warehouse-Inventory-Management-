-- Equipment Rental System - Table Creation Script
-- Target database: Apache Derby (Java DB)
-- Matches the columns used by the DAO classes in src/java/dao
-- If re-running on a database that already has these tables, drop
-- child tables before parent tables first:
-- DROP TABLE Payments; DROP TABLE Maintenance; DROP TABLE Cart;
-- DROP TABLE Rentals; DROP TABLE Equipment; DROP TABLE Employee; DROP TABLE Customer;

CREATE TABLE Customer (
    CustomerID   INTEGER        NOT NULL
                 GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
    UserName     VARCHAR(100)   NOT NULL,
    Email        VARCHAR(150)   NOT NULL,
    Password     VARCHAR(100)   NOT NULL,
    Role         VARCHAR(20)    DEFAULT 'CUSTOMER',
    CONSTRAINT PK_Customer PRIMARY KEY (CustomerID),
    CONSTRAINT UQ_Customer_Email UNIQUE (Email)
);

CREATE TABLE Employee (
    EmployeeID    INTEGER        NOT NULL
                  GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
    EmployeeName  VARCHAR(100)   NOT NULL,
    Email         VARCHAR(150)   NOT NULL,
    Password      VARCHAR(100)   NOT NULL,
    Position      VARCHAR(50),
    SupervisorID  INTEGER,
    Role          VARCHAR(20)    DEFAULT 'EMPLOYEE',
    CONSTRAINT PK_Employee PRIMARY KEY (EmployeeID),
    CONSTRAINT UQ_Employee_Email UNIQUE (Email),
    CONSTRAINT FK_Employee_Supervisor FOREIGN KEY (SupervisorID)
        REFERENCES Employee (EmployeeID)
);

CREATE TABLE Equipment (
    EquipmentID        INTEGER        NOT NULL
                        GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
    EquipmentName       VARCHAR(150)   NOT NULL,
    EquipmentType       VARCHAR(100),
    ConditionStatus      VARCHAR(20)    DEFAULT 'Good',
    PricePerDay         DECIMAL(10,2)  NOT NULL DEFAULT 0,
    AvailabilityStatus  BOOLEAN        DEFAULT TRUE,
    ImagePath           VARCHAR(255),
    CONSTRAINT PK_Equipment PRIMARY KEY (EquipmentID)
);

CREATE TABLE Cart (
    CartID       INTEGER   NOT NULL
                 GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
    CustomerID   INTEGER   NOT NULL,
    EquipmentID  INTEGER   NOT NULL,
    Quantity     INTEGER   NOT NULL DEFAULT 1,
    StartDate    DATE,
    EndDate      DATE,
    CONSTRAINT PK_Cart PRIMARY KEY (CartID),
    CONSTRAINT FK_Cart_Customer FOREIGN KEY (CustomerID)
        REFERENCES Customer (CustomerID) ON DELETE CASCADE,
    CONSTRAINT FK_Cart_Equipment FOREIGN KEY (EquipmentID)
        REFERENCES Equipment (EquipmentID) ON DELETE CASCADE
);

CREATE TABLE Rentals (
    RentalID     INTEGER        NOT NULL
                 GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
    CustomerID   INTEGER        NOT NULL,
    EmployeeID   INTEGER,
    EquipmentID  INTEGER        NOT NULL,
    StartDate    DATE,
    EndDate      DATE,
    Status       VARCHAR(20)    DEFAULT 'Pending',
    TotalAmount  DECIMAL(10,2)  NOT NULL DEFAULT 0,
    CONSTRAINT PK_Rentals PRIMARY KEY (RentalID),
    CONSTRAINT FK_Rentals_Customer FOREIGN KEY (CustomerID)
        REFERENCES Customer (CustomerID),
    CONSTRAINT FK_Rentals_Employee FOREIGN KEY (EmployeeID)
        REFERENCES Employee (EmployeeID),
    CONSTRAINT FK_Rentals_Equipment FOREIGN KEY (EquipmentID)
        REFERENCES Equipment (EquipmentID)
);

CREATE TABLE Payments (
    PaymentID      INTEGER        NOT NULL
                   GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
    RentalID       INTEGER        NOT NULL,
    Amount         DECIMAL(10,2)  NOT NULL,
    PaymentDate    DATE,
    PaymentMethod  VARCHAR(50),
    CONSTRAINT PK_Payments PRIMARY KEY (PaymentID),
    CONSTRAINT FK_Payments_Rental FOREIGN KEY (RentalID)
        REFERENCES Rentals (RentalID)
);

CREATE TABLE Maintenance (
    MaintenanceID  INTEGER        NOT NULL
                   GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
    EmployeeID     INTEGER        NOT NULL,
    EquipmentID    INTEGER        NOT NULL,
    Issue          VARCHAR(255),
    RepairDate     DATE,
    Status         VARCHAR(20)    DEFAULT 'Pending',
    CONSTRAINT PK_Maintenance PRIMARY KEY (MaintenanceID),
    CONSTRAINT FK_Maintenance_Employee FOREIGN KEY (EmployeeID)
        REFERENCES Employee (EmployeeID),
    CONSTRAINT FK_Maintenance_Equipment FOREIGN KEY (EquipmentID)
        REFERENCES Equipment (EquipmentID)
);
