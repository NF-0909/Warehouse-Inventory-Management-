-- Equipment Rental System - Sample Data Script
-- Target database: Apache Derby (Java DB)
-- Run 01_create_tables.sql first, on empty tables.
-- Foreign keys are looked up by name/email via subqueries instead of
-- hardcoded numbers, so this script works no matter what IDs the
-- identity columns actually generate.

INSERT INTO Customer (UserName, Email, Password, Role) VALUES ('Ali Hassan', 'ali.hassan@example.com', 'pass123', 'CUSTOMER');
INSERT INTO Customer (UserName, Email, Password, Role) VALUES ('Siti Nadia', 'siti.nadia@example.com', 'pass123', 'CUSTOMER');
INSERT INTO Customer (UserName, Email, Password, Role) VALUES ('John Tan', 'john.tan@example.com', 'pass123', 'CUSTOMER');

INSERT INTO Employee (EmployeeName, Email, Password, Position, SupervisorID, Role) VALUES ('employee', 'employee@gmail.com', '123', 'Manager', NULL, 'EMPLOYEE');

INSERT INTO Equipment (EquipmentName, EquipmentType, ConditionStatus, PricePerDay, AvailabilityStatus, ImagePath) VALUES ('Badminton Racket - Yonex', 'Badminton', 'Excellent', 15.00, TRUE, 'image/badminton-racket.jpg');
INSERT INTO Equipment (EquipmentName, EquipmentType, ConditionStatus, PricePerDay, AvailabilityStatus, ImagePath) VALUES ('Tennis Racket - Wilson', 'Tennis', 'Good', 20.00, TRUE, 'image/tennis-racket.jpg');
INSERT INTO Equipment (EquipmentName, EquipmentType, ConditionStatus, PricePerDay, AvailabilityStatus, ImagePath) VALUES ('Mountain Bike', 'Cycling', 'Good', 45.00, TRUE, 'image/mountain-bike.jpg');
INSERT INTO Equipment (EquipmentName, EquipmentType, ConditionStatus, PricePerDay, AvailabilityStatus, ImagePath) VALUES ('Camping Tent (4-person)', 'Camping', 'Fair', 35.00, TRUE, 'image/camping-tent.jpg');
INSERT INTO Equipment (EquipmentName, EquipmentType, ConditionStatus, PricePerDay, AvailabilityStatus, ImagePath) VALUES ('Football', 'Football', 'Good', 10.00, FALSE, 'image/football.jpg');
INSERT INTO Equipment (EquipmentName, EquipmentType, ConditionStatus, PricePerDay, AvailabilityStatus, ImagePath) VALUES ('Basketball', 'Basketball', 'Damaged', 8.00, FALSE, NULL);

INSERT INTO Cart (CustomerID, EquipmentID, Quantity, StartDate, EndDate)
VALUES ((SELECT CustomerID FROM Customer WHERE Email = 'ali.hassan@example.com'),
        (SELECT EquipmentID FROM Equipment WHERE EquipmentName = 'Tennis Racket - Wilson'),
        1, DATE('2026-07-20'), DATE('2026-07-22'));

INSERT INTO Cart (CustomerID, EquipmentID, Quantity, StartDate, EndDate)
VALUES ((SELECT CustomerID FROM Customer WHERE Email = 'siti.nadia@example.com'),
        (SELECT EquipmentID FROM Equipment WHERE EquipmentName = 'Mountain Bike'),
        1, DATE('2026-07-25'), DATE('2026-07-28'));

INSERT INTO Rentals (CustomerID, EmployeeID, EquipmentID, StartDate, EndDate, Status, TotalAmount)
VALUES ((SELECT CustomerID FROM Customer WHERE Email = 'ali.hassan@example.com'),
        (SELECT EmployeeID FROM Employee WHERE Email = 'lim.weijie@example.com'),
        (SELECT EquipmentID FROM Equipment WHERE EquipmentName = 'Badminton Racket - Yonex'),
        DATE('2026-06-01'), DATE('2026-06-05'), 'Returned', 60.00);

INSERT INTO Rentals (CustomerID, EmployeeID, EquipmentID, StartDate, EndDate, Status, TotalAmount)
VALUES ((SELECT CustomerID FROM Customer WHERE Email = 'john.tan@example.com'),
        (SELECT EmployeeID FROM Employee WHERE Email = 'rahman.ismail@example.com'),
        (SELECT EquipmentID FROM Equipment WHERE EquipmentName = 'Camping Tent (4-person)'),
        DATE('2026-07-01'), DATE('2026-07-04'), 'Approved', 105.00);

INSERT INTO Rentals (CustomerID, EmployeeID, EquipmentID, StartDate, EndDate, Status, TotalAmount)
VALUES ((SELECT CustomerID FROM Customer WHERE Email = 'siti.nadia@example.com'),
        NULL,
        (SELECT EquipmentID FROM Equipment WHERE EquipmentName = 'Mountain Bike'),
        CURRENT_DATE, NULL, 'Pending', 90.00);

INSERT INTO Payments (RentalID, Amount, PaymentDate, PaymentMethod)
VALUES ((SELECT RentalID FROM Rentals WHERE CustomerID = (SELECT CustomerID FROM Customer WHERE Email = 'ali.hassan@example.com')
         AND EquipmentID = (SELECT EquipmentID FROM Equipment WHERE EquipmentName = 'Badminton Racket - Yonex')),
        60.00, DATE('2026-06-01'), 'Credit Card');

INSERT INTO Payments (RentalID, Amount, PaymentDate, PaymentMethod)
VALUES ((SELECT RentalID FROM Rentals WHERE CustomerID = (SELECT CustomerID FROM Customer WHERE Email = 'john.tan@example.com')
         AND EquipmentID = (SELECT EquipmentID FROM Equipment WHERE EquipmentName = 'Camping Tent (4-person)')),
        105.00, DATE('2026-07-01'), 'Online Banking');

INSERT INTO Maintenance (EmployeeID, EquipmentID, Issue, RepairDate, Status)
VALUES ((SELECT EmployeeID FROM Employee WHERE Email = 'lim.weijie@example.com'),
        (SELECT EquipmentID FROM Equipment WHERE EquipmentName = 'Basketball'),
        'Punctured, needs replacement bladder', DATE('2026-07-05'), 'In Progress');

INSERT INTO Maintenance (EmployeeID, EquipmentID, Issue, RepairDate, Status)
VALUES ((SELECT EmployeeID FROM Employee WHERE Email = 'rahman.ismail@example.com'),
        (SELECT EquipmentID FROM Equipment WHERE EquipmentName = 'Football'),
        'Deflated, valve stuck', DATE('2026-06-20'), 'Completed');
